﻿
namespace SerialReader
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbPort = new System.Windows.Forms.Label();
            this.cbPort = new System.Windows.Forms.ComboBox();
            this.lbBaud = new System.Windows.Forms.Label();
            this.cbBaudRate = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lbConnectStatusMsg = new System.Windows.Forms.Label();
            this.btnRefPort = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.serialReaderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decoderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbPort
            // 
            this.lbPort.AutoSize = true;
            this.lbPort.Location = new System.Drawing.Point(95, 61);
            this.lbPort.Name = "lbPort";
            this.lbPort.Size = new System.Drawing.Size(31, 16);
            this.lbPort.TabIndex = 1;
            this.lbPort.Text = "Port";
            // 
            // cbPort
            // 
            this.cbPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cbPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPort.ForeColor = System.Drawing.Color.Black;
            this.cbPort.FormattingEnabled = true;
            this.cbPort.Location = new System.Drawing.Point(98, 93);
            this.cbPort.Name = "cbPort";
            this.cbPort.Size = new System.Drawing.Size(121, 24);
            this.cbPort.TabIndex = 2;
            // 
            // lbBaud
            // 
            this.lbBaud.AutoSize = true;
            this.lbBaud.Location = new System.Drawing.Point(445, 61);
            this.lbBaud.Name = "lbBaud";
            this.lbBaud.Size = new System.Drawing.Size(71, 16);
            this.lbBaud.TabIndex = 3;
            this.lbBaud.Text = "Baud Rate";
            // 
            // cbBaudRate
            // 
            this.cbBaudRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cbBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudRate.FormattingEnabled = true;
            this.cbBaudRate.Items.AddRange(new object[] {
            "9600",
            "115200"});
            this.cbBaudRate.Location = new System.Drawing.Point(442, 93);
            this.cbBaudRate.Name = "cbBaudRate";
            this.cbBaudRate.Size = new System.Drawing.Size(121, 24);
            this.cbBaudRate.TabIndex = 4;
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.Lime;
            this.btnConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.ForeColor = System.Drawing.Color.DimGray;
            this.btnConnect.Location = new System.Drawing.Point(101, 161);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(86, 35);
            this.btnConnect.TabIndex = 9;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // lbConnectStatusMsg
            // 
            this.lbConnectStatusMsg.AutoSize = true;
            this.lbConnectStatusMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbConnectStatusMsg.ForeColor = System.Drawing.Color.Red;
            this.lbConnectStatusMsg.Location = new System.Drawing.Point(98, 221);
            this.lbConnectStatusMsg.Name = "lbConnectStatusMsg";
            this.lbConnectStatusMsg.Size = new System.Drawing.Size(148, 16);
            this.lbConnectStatusMsg.TabIndex = 12;
            this.lbConnectStatusMsg.Text = "lbConnectStatusMsg";
            this.lbConnectStatusMsg.Visible = false;
            // 
            // btnRefPort
            // 
            this.btnRefPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnRefPort.Location = new System.Drawing.Point(258, 93);
            this.btnRefPort.Name = "btnRefPort";
            this.btnRefPort.Size = new System.Drawing.Size(107, 30);
            this.btnRefPort.TabIndex = 13;
            this.btnRefPort.Text = "Refresh Port";
            this.btnRefPort.UseVisualStyleBackColor = false;
            this.btnRefPort.Click += new System.EventHandler(this.btnRefPort_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.serialReaderToolStripMenuItem,
            this.decoderToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(936, 30);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // serialReaderToolStripMenuItem
            // 
            this.serialReaderToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.serialReaderToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.serialReaderToolStripMenuItem.Name = "serialReaderToolStripMenuItem";
            this.serialReaderToolStripMenuItem.Size = new System.Drawing.Size(111, 26);
            this.serialReaderToolStripMenuItem.Text = "Serial Reader";
            this.serialReaderToolStripMenuItem.Click += new System.EventHandler(this.serialReaderToolStripMenuItem_Click);
            // 
            // decoderToolStripMenuItem
            // 
            this.decoderToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.decoderToolStripMenuItem.Checked = true;
            this.decoderToolStripMenuItem.CheckOnClick = true;
            this.decoderToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.decoderToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.decoderToolStripMenuItem.Name = "decoderToolStripMenuItem";
            this.decoderToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.decoderToolStripMenuItem.Text = "Decoder";
            this.decoderToolStripMenuItem.Click += new System.EventHandler(this.decoderToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(936, 454);
            this.Controls.Add(this.btnRefPort);
            this.Controls.Add(this.lbConnectStatusMsg);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.cbBaudRate);
            this.Controls.Add(this.lbBaud);
            this.Controls.Add(this.cbPort);
            this.Controls.Add(this.lbPort);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Serial Reader";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbPort;
        private System.Windows.Forms.ComboBox cbPort;
        private System.Windows.Forms.Label lbBaud;
        private System.Windows.Forms.ComboBox cbBaudRate;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label lbConnectStatusMsg;
        private System.Collections.Generic.List<ConnForm> connectedPortList;
        private System.Windows.Forms.Button btnRefPort;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem serialReaderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decoderToolStripMenuItem;
    }
}

