﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Ports;
using System.Net.Security;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SerialReader
{
    public partial class ConnForm : Form
    {
        /* Custom member objects */
        bool iosModeSet = false;
        bool isReady = false;
        byte[] certUpdateMsg = null;
        bool certUpdate = false;
        private string serialResp;
        private UInt32 rootCAFileSize;
        private UInt32 deviceChainCertFileSize;
        private UInt32 deviceKeyCertFileSize;
        private UInt32 fwImageFileSize;
        private UInt32 deviceID;
        private byte fwMajorVersion;
        private byte fwMinorVersion;
        private bool pageStillRemainig = false;
        private ulong totalBytesRead = 0;
        int dataSentCount = 0;
        bool isThreadRunning = false;
        bool threadShouldStop = false;
        SemaphoreSlim mySemaphore = new SemaphoreSlim(0, 1);

        void sendCertUpdateMsg()
        {
            try
            {
                if ((certUpdateMsg != null) && certUpdateMsg.Length > 0)
                {
                    string strng = Encoding.ASCII.GetString(certUpdateMsg);
                    serialPortObj.Write(certUpdateMsg, 0, certUpdateMsg.Length);

                    if (certUpdateMsg[0] == 106)
                    {
                        lbSentCmd.Text = "SET ROOTCA";
                    }
                    else if (certUpdateMsg[0] == 107)
                    {
                        lbSentCmd.Text = "SET DEVCHAIN";
                    }
                    else if (certUpdateMsg[0] == 108)
                    {
                        lbSentCmd.Text = "SET DEVKEY";
                    }
                    lbSentCmd.Visible = true;
                }
            }
            catch (InvalidOperationException e1)
            {
                txtRecvMsg.AppendText("\n");
                Color oldColor = txtRecvMsg.ForeColor;
                txtRecvMsg.ForeColor = Color.Red;
                txtRecvMsg.AppendText(e1.Message);
                txtRecvMsg.ForeColor = oldColor;
            }
        }

        public ConnForm(string portName, int baudRate)
        {
            InitializeComponent();
            cbCommand.SelectedIndex = 0;
            this.Text = portName;

            serialPortObj.PortName = portName;
            serialPortObj.BaudRate = baudRate;
            serialPortObj.ReadTimeout = 1000;
            try
            {
                serialPortObj.Open();
            }
            catch (IOException ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An unexpected error occurred: " + ex.Message);
                //System.Windows.Forms.Application.Exit();
                this.Close();
                return;
            }
            serialPortObj.DataReceived += new SerialDataReceivedEventHandler(ReadSerialData);
        }

        private void ReadSerialData(object sender, SerialDataReceivedEventArgs e)
        {
            // Show all the incoming data in the port's buffer
            serialResp = serialPortObj.ReadExisting();
            if (serialResp == "Fail")
            {
                lbResult.Text = lbSentCmd.Text + serialResp.ToUpper();
                lbResult.ForeColor = Color.Black;
                lbResult.BackColor = Color.Red;
                lbResult.TextAlign = ContentAlignment.MiddleCenter;
                lbResult.Visible = true;

                if (cbCommand.SelectedItem.ToString() == "Check Device Ready")
                {
                    pbWaitReady.Enabled = true;
                    pbWaitReady.Visible = true;
                }
                else if (lbSentCmd.Text == "SET DEVKEY" ||
                    lbSentCmd.Text == "SET DEVCHAIN" ||
                    lbSentCmd.Text == "SET ROOTCA")
                {
                    pbWaitReady.Enabled = false;
                    pbWaitReady.Visible = false;
                    lbAlert.Text = "UPDATING CERT FAILED !!!";
                    lbAlert.ForeColor = Color.DarkRed;
                    lbAlert.Enabled = true;
                    lbAlert.Visible = true;
                }
                else if (lbSentCmd.Text == "CERT RDY")
                {
                    pbWaitReady.Enabled = false;
                    pbWaitReady.Visible = false;
                    lbAlert.Text = "CERT READY FAILED !!!";
                    lbAlert.ForeColor = Color.DarkRed;
                    lbAlert.Enabled = true;
                    lbAlert.Visible = true;
                }
            }
            else if ((serialResp == "Pass")||(serialResp.Contains("P"))||(serialResp.Contains("Pa"))||(serialResp.Contains("Pas")))
            {
                lbResult.Enabled = true;
                lbResult.Text = lbSentCmd.Text + " PASS";
                lbResult.ForeColor = Color.Black;
                lbResult.BackColor = Color.LightGreen;
                lbResult.TextAlign = ContentAlignment.MiddleCenter;
                lbResult.Visible = true;

                if (lbSentCmd.Text == "SET DEVKEY" ||
                    lbSentCmd.Text == "SET DEVCHAIN" ||
                    lbSentCmd.Text == "SET ROOTCA")
                {
                    pbWaitReady.Enabled = false;
                    pbWaitReady.Visible = false;
                    lbAlert.Text = "UPDATE COMPLETED SUCESSFULLY!!!";
                    lbAlert.ForeColor = Color.DarkGreen;
                    lbAlert.Enabled = true;
                    lbAlert.Visible = true;
                }
                //else if (cbCommand.SelectedItem.ToString() == "update cert-rootca")
                else if (certUpdate == true)
                {
                    certUpdate = false;
                    Thread.Sleep(2000);
                    sendCertUpdateMsg();
                }

                if (lbSentCmd.Text == "DEV CONNECT")
                {
                    iosModeSet = true;
                    pbWaitReady.Enabled = false;
                    pbWaitReady.Visible = false;
                    lbAlert.Text = "IOS MODE SET SUCESSFULLY!!!";
                    lbAlert.ForeColor = Color.DarkGreen;
                    lbAlert.Enabled = true;
                    lbAlert.Visible = true;
                }

            }
            else if (serialResp.Length > 4)
            {
                if (serialResp.Substring(serialResp.Length - 4) == "Pass")
                {
                    lbResult.Text = lbSentCmd.Text + " PASS";
                    lbResult.ForeColor = Color.Black;
                    lbResult.BackColor = Color.LightGreen;
                    lbResult.TextAlign = ContentAlignment.MiddleCenter;
                    lbResult.Enabled = true;
                    lbResult.Visible = true;
                }

                txtRecvMsg.AppendText(serialResp);
                txtRecvMsg.AppendText(Environment.NewLine);

                string text = txtRecvMsg.Text;

                // Get the number of bytes of the text using the UTF-8 encoding
                int byteCount = System.Text.Encoding.UTF8.GetByteCount(text);

                // Display the byte count in a label
                lbStringBytes.Text = byteCount.ToString() + " bytes";

            }
            else
            {
                txtRecvMsg.AppendText(serialResp);
                txtRecvMsg.AppendText(Environment.NewLine);

                string text = txtRecvMsg.Text;

                // Get the number of bytes of the text using the UTF-8 encoding
                int byteCount = System.Text.Encoding.UTF8.GetByteCount(text);

                // Display the byte count in a label
                lbStringBytes.Text = byteCount.ToString() + " bytes";
            }
            /*if ((cbLogDataDatePicker.SelectedItem.ToString() == "All Data")
                 && (cbCommand.SelectedItem.ToString() == "Write File")
                 && (cbLogDataDatePicker.SelectedItem != null)
                 && (cbCommand.SelectedItem != null)*/
            if (pageStillRemainig == true)
            {
                Thread.Sleep(3000);
                Console.WriteLine("\ncurrent count before release " + mySemaphore.CurrentCount.ToString());
                mySemaphore.Release();
                Console.WriteLine("\ncurrent count after release " + mySemaphore.CurrentCount.ToString());
            }
        }

        private void RootCACtrlEnabled(bool enable)
        {
            lbRootCAFileName.Text = "No file selected";
            lbRootCAFileName.Visible = enable;
            lbRootCAFileName.Enabled = enable;

            btnSelectRootCACert.Visible = enable;
            btnSelectRootCACert.Enabled = enable;
        }

        private void DeviceChainCtrlEnabled(bool enable)
        {
            lbDevChainCertFileName.Text = "No file selected";
            lbDevChainCertFileName.Visible = enable;
            lbDevChainCertFileName.Enabled = enable;

            btnSelectDevChainCert.Visible = enable;
            btnSelectDevChainCert.Enabled = enable;
        }

        private void DeviceKeyCtrlEnabled(bool enable)
        {
            lbDevKeyCertFileName.Text = "No file selected";
            lbDevKeyCertFileName.Visible = enable;
            lbDevKeyCertFileName.Enabled = enable;

            btnSelectDevKeyCert.Visible = enable;
            btnSelectDevKeyCert.Enabled = enable;
        }

        private void FwImageCtrlEnabled(bool enable)
        {
            lbFwImageFileName.Text = "No file selected";
            lbFwImageFileName.Visible = enable;
            lbFwImageFileName.Enabled = enable;

            btnSelectFwImage.Visible = enable;
            btnSelectFwImage.Enabled = enable;
        }

        private void FwVersionCtrlEnabled(bool enable)
        {
            lbFwVersion.Visible = enable;
            lbFwVersion.Enabled = enable;

            lbFwVerMajor.Visible = enable;
            lbFwVerMajor.Enabled = enable;

            numUDFwMajor.Visible = enable;
            numUDFwMajor.Enabled = enable;

            lbFwVerMinor.Visible = enable;
            lbFwVerMinor.Enabled = enable;

            numUDFwMinor.Visible = enable;
            numUDFwMinor.Enabled = enable;
        }

        private void DeviceIDCtrlEnabled(bool enable)
        {
            lbDevID.Visible = enable;
            lbDevID.Enabled = enable;

            numUDDeviceID.Visible = enable;
            numUDDeviceID.Enabled = enable;
        }

        private void EnableDeviceMetaParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableSetRTCParams(false);
                EnableReadLogParams(false);
            }
            set_textAndLabelToDefault(false);

            this.btnSelectRootCACert.Location = new System.Drawing.Point(19, 31);
            this.btnSelectDevChainCert.Location = new System.Drawing.Point(19, 74);
            this.btnSelectDevKeyCert.Location = new System.Drawing.Point(19, 120);

            this.lbRootCAFileName.Location = new System.Drawing.Point(210, 31);
            this.lbRootCAFileName.ForeColor = System.Drawing.Color.Black;
            this.lbDevChainCertFileName.Location = new System.Drawing.Point(210, 74);
            this.lbDevChainCertFileName.ForeColor = System.Drawing.Color.Black;
            this.lbDevKeyCertFileName.Location = new System.Drawing.Point(210, 120);
            this.lbDevKeyCertFileName.ForeColor = System.Drawing.Color.Black;

            RootCACtrlEnabled(enable);
            DeviceChainCtrlEnabled(enable);
            DeviceKeyCtrlEnabled(enable);
            FwImageCtrlEnabled(enable);
            FwVersionCtrlEnabled(enable);
            DeviceIDCtrlEnabled(enable);
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableRootCaParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableSetRTCParams(false);
                EnableReadLogParams(false);
                openFileCert.FileName = string.Empty;
            }
            set_textAndLabelToDefault(false);
            RootCACtrlEnabled(enable);
            DeviceChainCtrlEnabled(false);
            DeviceKeyCtrlEnabled(false);
            this.btnSelectRootCACert.Location = new System.Drawing.Point(20, 31);
            lbRootCAFileName.Location = new System.Drawing.Point(283, 35);
            lbRootCAFileName.Text = string.Empty;
            FwImageCtrlEnabled(false);
            FwVersionCtrlEnabled(false);
            DeviceIDCtrlEnabled(false);
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableDeviceChainParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableSetRTCParams(false);
                EnableReadLogParams(false);
                openFileCert.FileName = string.Empty;
            }
            set_textAndLabelToDefault(false);
            RootCACtrlEnabled(false);
            DeviceChainCtrlEnabled(enable);
            DeviceKeyCtrlEnabled(false);
            this.btnSelectDevChainCert.Location = new System.Drawing.Point(20, 31);
            lbDevChainCertFileName.Location = new System.Drawing.Point(283, 35);
            lbDevChainCertFileName.Text = string.Empty;
            FwImageCtrlEnabled(false);
            FwVersionCtrlEnabled(false);
            DeviceIDCtrlEnabled(false);
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableDeviceKeyParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableSetRTCParams(false);
                EnableReadLogParams(false);
                openFileCert.FileName = string.Empty;
            }
            set_textAndLabelToDefault(false);
            RootCACtrlEnabled(false);
            DeviceChainCtrlEnabled(false);
            DeviceKeyCtrlEnabled(enable);
            this.btnSelectDevKeyCert.Location = new System.Drawing.Point(20, 31);
            lbDevKeyCertFileName.Location = new System.Drawing.Point(283, 35);
            lbDevKeyCertFileName.Text = string.Empty;
            FwImageCtrlEnabled(false);
            FwVersionCtrlEnabled(false);
            DeviceIDCtrlEnabled(false);
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableSetRTCParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableDeviceMetaParams(false);
                EnableReadLogParams(false);
                lbSentCmd.Text = "SET RTC ";
            }
            set_textAndLabelToDefault(false);
            lbDevKeyCertFileName.Text = "RTC time value:";
            lbDevKeyCertFileName.Enabled = enable;
            lbDevKeyCertFileName.Visible = enable;

            dtpDateTime.Format = DateTimePickerFormat.Custom;
            dtpDateTime.CustomFormat = "MM/dd/yyyy hh:mm:ss";
            dtpDateTime.Value = DateTime.Now;
            dtpDateTime.Enabled = enable;
            dtpDateTime.Visible = enable;
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableCertUpdateIndParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableDeviceMetaParams(false);
                EnableReadLogParams(false);
                EnableSetRTCParams(false);
                lbSentCmd.Text = "CERT UPDATE IND";
            }
            set_textAndLabelToDefault(false);
            lbDevKeyCertFileName.Text = "No parameters needed. Just press send button.";
            lbDevKeyCertFileName.Enabled = enable;
            lbDevKeyCertFileName.Visible = enable;
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableCheckDeviceReadyParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableDeviceMetaParams(false);
                EnableReadLogParams(false);
                EnableSetRTCParams(false);
                lbSentCmd.Text = "CHK DEV RDY";
            }
            set_textAndLabelToDefault(false);
            lbDevKeyCertFileName.Text = "No parameters needed. Just press send button.";
            lbDevKeyCertFileName.Enabled = enable;
            lbDevKeyCertFileName.Visible = enable;
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableDeviceConnectParam(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableDeviceMetaParams(false);
                EnableReadLogParams(false);
                EnableSetRTCParams(false);
                lbSentCmd.Text = "DEV CONNECT";
            }
            set_textAndLabelToDefault(false);
            lbDevKeyCertFileName.Text = "No parameters needed. Just press send button.";
            lbDevKeyCertFileName.Enabled = enable;
            lbDevKeyCertFileName.Visible = enable;
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableUpdateReady(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableDeviceMetaParams(false);
                EnableReadLogParams(false);
                EnableSetRTCParams(false);
            }
            set_textAndLabelToDefault(false);
            lbDevKeyCertFileName.Text = "No parameters needed. Just press send button.";
            lbDevKeyCertFileName.Enabled = enable;
            lbDevKeyCertFileName.Visible = enable;
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableFileSelectParams(bool enable)
        {
            if (enable)
            {
                EnableDeviceMetaParams(false);
                EnableReadLogParams(false);
                EnableSetRTCParams(false);
                cbSelectInputMethod.Visible = enable;
                cbSelectInputMethod.Enabled = enable;
                lbSelectInputMethod.Visible = enable;
                lbSelectInputMethod.Enabled = enable;
                //cbLogDataDatePicker.Items[1].Enabled = false;
                lbFwImageFileName.Text = "No file selected";
            }
            if ((!enable) || (cbCommand.SelectedItem.ToString() == "Read File"))
            {
                cbSelectInputMethod.Visible = false;
                cbSelectInputMethod.Enabled = false;
                lbSelectInputMethod.Visible = false;
                lbSelectInputMethod.Enabled = false;
            }
            if (cbSelectInputMethod.SelectedItem != null && (cbCommand.SelectedItem.ToString() == "Write File") &&
                (cbSelectInputMethod.SelectedItem.ToString() == "Input Text"))
            {
                txtRecvMsg.ReadOnly = false;
                lbFwImageFileName.Text = "";
                lbFwImageFileName.Visible = false;
            }
            cbSelectFileType.Enabled = enable;
            cbSelectFileType.Visible = enable;
            lbSelectFileType.Visible = enable;
            lbSelectFileType.Enabled = enable;
            cbLogDataDatePicker.Enabled = enable;
            cbLogDataDatePicker.Visible = enable;
            lbDevChainCertFileName.Text = "Select Date range:";
            lbDevChainCertFileName.Enabled = enable;
            lbDevChainCertFileName.Visible = enable;
            cbSelectFileType.SelectedIndex = 0;
            cbLogDataDatePicker.SelectedIndex = 0;
            set_textAndLabelToDefault(false);
        }

        private void EnableEraseExtFlashParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableDeviceMetaParams(false);
                EnableReadLogParams(false);
                EnableSetRTCParams(false);
            }
            set_textAndLabelToDefault(false);
            lbDevKeyCertFileName.Text = "No parameters needed. Just press send button.";
            lbDevKeyCertFileName.Enabled = enable;
            lbDevKeyCertFileName.Visible = enable;
            txtRecvMsg.ReadOnly = true;
        }

        private void EnableReadLogParams(bool enable)
        {
            if (enable)
            {
                EnableFileSelectParams(false);
                EnableDeviceMetaParams(false);
                EnableSetRTCParams(false);
            }
            set_textAndLabelToDefault(false);
            lbDevChainCertFileName.Text = "Select Date range:";
            lbDevChainCertFileName.Enabled = enable;
            lbDevChainCertFileName.Visible = enable;
            cbLogDataDatePicker.Enabled = enable;
            cbLogDataDatePicker.Visible = enable;
            cbLogDataDatePicker.SelectedIndex = 0;
            txtRecvMsg.ReadOnly = true;
        }

        private void SetCmdDesc(string desc)
        {
            lbCmdDesc.Text = desc;
            lbCmdDesc.Enabled = true;
            lbCmdDesc.Visible = true;
            lbCmdDesc.ForeColor = Color.Gray;
        }

        private void SetCmdDesc(string desc, Color col)
        {
            lbCmdDesc.Text = desc;
            lbCmdDesc.Enabled = true;
            lbCmdDesc.Visible = true;
            lbCmdDesc.ForeColor = col;
        }

        private void set_textAndLabelToDefault(bool enable)
        {
            //txtRecvMsg.ReadOnly = !enable;
            btStop.Visible = false;
            dataSentCount = 0;
            totalBytesRead = 0;
            txtRecvMsg.Text = string.Empty;
            lbResult.Text = "";
            lbResult.Visible = enable;
            lbStringBytes.Text = "0 bytes";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbSentCmd.Text = string.Empty;
            lbSentCmd.Visible = false;
            lbAlert.Text = string.Empty;
            lbAlert.Visible = false;
            if (iosModeSet || cbCommand.SelectedItem.ToString() == "Device connect" || cbCommand.SelectedItem.ToString() == "Check Device Ready")
            {
                btnSend.Enabled = true;
                switch (cbCommand.SelectedItem.ToString()) /////using switch to test as to what was selected from the first combobox
                {
                    case "Device Meta Data Update":
                        SetCmdDesc("Command Desc: Set device meta data parameters");
                        EnableDeviceMetaParams(true);
                        break;

                    case "Device connect":
                        SetCmdDesc("Command Desc: set ios mode");
                        EnableDeviceConnectParam(true);
                        break;

                    case "Certificate Update Indication":
                        SetCmdDesc("Command Desc: Send indication to update security certificates on modem");
                        EnableCertUpdateIndParams(true);
                        break;

                    case "Set Device RTC":
                        SetCmdDesc("Command Desc: Set RTC value");
                        EnableSetRTCParams(true);
                        break;

                    case "Read Telemetry Data":
                        SetCmdDesc("Command Desc: Read telemetry log data");
                        EnableReadLogParams(true);
                        break;

                    case "Erase External Flash Memory":
                        SetCmdDesc("Command Desc: Erase ecternal flash memory");
                        EnableEraseExtFlashParams(true);
                        break;

                    case "Read System Log":
                        SetCmdDesc("Command Desc: Read system log data");
                        EnableReadLogParams(true);
                        break;

                    case "Session Close":
                        //threadShouldStop = true;
                        SetCmdDesc("Command Desc: Close this session with the device");
                        break;

                    case "Check Device Ready":
                        SetCmdDesc("Command Desc: Check if the device is ready to take commands");
                        EnableCheckDeviceReadyParams(true);
                        break;

                    case "Read File":
                    case "Write File":
                        SetCmdDesc("Command Desc: Select file mode for file write operation");
                        EnableFileSelectParams(true);
                        break;

                    //case "update cert ready":
                    //    SetCmdDesc("Command Desc: update ready");
                    //    EnableUpdateReady(true);
                    //    break;

                    case "update cert-rootca":
                        SetCmdDesc("Command Desc: update root ca");
                        EnableRootCaParams(true);
                        break;

                    case "update cert-devchain":
                        SetCmdDesc("Command Desc: update device chain certificate");
                        EnableDeviceChainParams(true);
                        break;

                    case "update cert-devkey":
                        SetCmdDesc("Command Desc: update device key");
                        EnableDeviceKeyParams(true);
                        break;

                    default:
                        SetCmdDesc("Command Desc: Please select a command from the above dropdown menu");
                        break;
                }
            }
            else if(!isReady)
            {
                lbDevKeyCertFileName.Text = "\nCheck for device ready !!";
                lbDevKeyCertFileName.ForeColor = Color.Black;
                lbDevKeyCertFileName.Visible = true;
                lbDevKeyCertFileName.Enabled = true;
                btnSend.Enabled = false;
            }
            else
            {
                lbDevKeyCertFileName.Text = "\nios mode not set, select \"DEV CONNECT\" option";
                lbDevKeyCertFileName.ForeColor = Color.Red;
                btnSend.Enabled = false;
            }
        }

        private byte[] UInt32ToNetworkByteOrder(UInt32 num)
        {
            byte[] arr = new byte[4];
            arr[0] = (byte)((num & 0xFF000000) >> 24);
            arr[1] = (byte)((num & 0x00FF0000) >> 16);
            arr[2] = (byte)((num & 0x0000FF00) >> 8);
            arr[3] = (byte)(num & 0x000000FF);

            return arr;
        }

        private byte[] UInt16ToNetworkByteOrder(UInt16 num)
        {
            byte[] arr = new byte[2];

            arr[0] = (byte)((num & 0xFF00) >> 8);
            arr[1] = (byte)(num & 0x00FF);

            return arr;
        }

        private byte[] MakeDeviceMetaDataUpdateMsg()
        {
            /* payload is 22 byte data:
             * first 4 bytes for devID,
             * next 4 bytes for firmware size,
             * next 2 bytes for firware version: one byte each for major & minor version respectively
             * next 4 bytes for root CA certificate size,
             * next 4 bytes for device chain certificate size
             * and last 4 bytes for device key certificate size
             */
            const UInt16 payloadLen = 22;
            List<byte> msg = new List<byte>();

            /* Add header in the message stream */
            //msg.AddRange(MSG_HEADER);

            /* Add type of the message */
            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_SET_DEV_META);

            /* Add length of the payload */
            msg.AddRange(UInt16ToNetworkByteOrder(payloadLen));

            /* Fill payload */
            msg.AddRange(UInt32ToNetworkByteOrder(deviceID));
            msg.AddRange(UInt32ToNetworkByteOrder(fwImageFileSize));
            msg.Add(fwMajorVersion);
            msg.Add(fwMinorVersion);
            msg.AddRange(UInt32ToNetworkByteOrder(rootCAFileSize));
            msg.AddRange(UInt32ToNetworkByteOrder(deviceChainCertFileSize));
            msg.AddRange(UInt32ToNetworkByteOrder(deviceKeyCertFileSize));

            return msg.ToArray();
        }

        private bool ValidateDeviceMetaParams(ref string err, string certType)
        {
            bool validated = true;
            err = "";

            if ((File.Exists(lbRootCAFileName.Text) && certType == "Device Meta Data Update") ||
                (File.Exists(lbRootCAFileName.Text) && certType == "update cert-rootca"))
            {
                rootCAFileSize = (UInt32)(new FileInfo(lbRootCAFileName.Text).Length);
            }
            else if (certType == "Device Meta Data Update")
            {
                validated = false;
                err = lbRootCAFileName.Text;
            }

            if ((File.Exists(lbDevChainCertFileName.Text) && certType == "Device Meta Data Update") ||
                (File.Exists(lbRootCAFileName.Text) && certType == "update cert-devchain"))
            {
                deviceChainCertFileSize = (UInt32)(new FileInfo(lbDevChainCertFileName.Text).Length);
            }
            else if (certType == "Device Meta Data Update")
            {
                validated = false;
                if (lbCmdDesc.Text != "")
                {
                    err += " & " + lbDevChainCertFileName.Text;
                }
                else
                {
                    err = lbDevChainCertFileName.Text;
                }
            }

            if ((File.Exists(lbDevKeyCertFileName.Text) && certType == "Device Meta Data Update") ||
                (File.Exists(lbRootCAFileName.Text) && certType == "update cert-devkey"))
            {
                deviceKeyCertFileSize = (UInt32)(new FileInfo(lbDevKeyCertFileName.Text).Length);
            }
            else if (certType == "Device Meta Data Update")
            {
                validated = false;
                if (err != "")
                {
                    err += " & " + lbDevKeyCertFileName.Text;
                }
                else
                {
                    err = lbDevKeyCertFileName.Text;
                }
            }

            if (certType == "Device Meta Data Update")
            {

                if (File.Exists(lbFwImageFileName.Text))
                {
                    fwImageFileSize = (UInt32)(new FileInfo(lbFwImageFileName.Text).Length);
                }
                else
                {
                    validated = false;
                    if (err != "")
                    {
                        err += " & " + lbFwImageFileName.Text;
                    }
                    else
                    {
                        err = lbFwImageFileName.Text;
                    }
                }

                if (err != "")
                {
                    err += " not found.";
                }

                fwMajorVersion = (byte)numUDFwMajor.Value;
                fwMinorVersion = (byte)numUDFwMinor.Value;
                deviceID = (byte)numUDDeviceID.Value;
            }

            return validated;
        }

        private byte[] MakeCertificateUpdateMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            /* Add header to the message stream */
            //msg.AddRange(MSG_HEADER);

            /* Add type of the message */
            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_CONFIG_CERTS);

            /* Add length of the payload */
            msg.AddRange(length);

            /* Add payload */
            //No payload required for this command;

            return msg.ToArray();
        }

        private byte[] MakeReadTelemetryDataMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            /* Add header to the message stream */
            //msg.AddRange(MSG_HEADER);

            if (cbLogDataDatePicker.SelectedItem.ToString() == "All Data")
            {
                /* Add type of the message */
                msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_REC_ALL);

                /* Add length of the payload */
                msg.AddRange(length);

                /* Add payload */
                //No payload required for this command;
            }
            else
            {
                /* Add type of the message */
                msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_REC_BY_DATE);

                length[0] = 0;
                length[1] = 3; /* 3 bytes of payload */

                int day = dtpDateTime.Value.Day;
                int month = dtpDateTime.Value.Month;
                int year = dtpDateTime.Value.Year;
                year -= 2000; /* Year value is assumed to be based on year 2000 */

                /* Add length of the payload */
                msg.AddRange(length);

                /* Add payload */
                msg.Add((byte)day);
                msg.Add((byte)month);
                msg.Add((byte)year);
            }

            return msg.ToArray();
        }

        private byte[] MakeSetDeviceRtcMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 6 }; /* 6 bytes of payload */
            byte hours = (byte)dtpDateTime.Value.Hour;
            byte minutes = (byte)dtpDateTime.Value.Minute;
            byte seconds = (byte)dtpDateTime.Value.Second;
            byte days = (byte)dtpDateTime.Value.Day;
            byte months = (byte)dtpDateTime.Value.Month;
            int years = dtpDateTime.Value.Year;
            years -= 2000; /* Years value is assumed to be based on the year 2000 */

            /* Add header to the message stream */
            //msg.AddRange(MSG_HEADER);

            /* Add type of the message */
            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_SET_RTC);

            /* Add length of the payload */
            msg.AddRange(length);

            /* Add payload */
            msg.Add(hours);
            msg.Add(minutes);
            msg.Add(seconds);
            msg.Add(days);
            msg.Add(months);
            msg.Add((byte)years);

            return msg.ToArray();
        }

        private byte[] MakeEraseFlashMemoryMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            /* Add header to the message stream */
            //msg.AddRange(MSG_HEADER);

            /* Add type of the message */
            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_ERASE_EXT_FLASH);

            /* Add length of the payload */
            msg.AddRange(length);

            /* Add payload */
            //No payload required for this command;

            return msg.ToArray();
        }

        private byte[] MakeDeviceLogReadMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            /* Add header to the message stream */
            //msg.AddRange(MSG_HEADER);

            if (cbLogDataDatePicker.SelectedItem.ToString() == "All Data")
            {
                /* Add type of the message */
                msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_SYS_LOG_ALL);

                /* Add length of the payload */
                msg.AddRange(length);

                /* Add payload */
                //No payload required for this command;
            }
            else
            {
                /* Add type of the message */
                msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_SYS_LOG_BY_DATE);
                length[0] = 0;
                length[1] = 3; /* 3 bytes of payload */

                int day = dtpDateTime.Value.Day;
                int month = dtpDateTime.Value.Month;
                int year = dtpDateTime.Value.Year;
                year -= 2000; /* Year value is assumed to be based on year 2000 */

                /* Add length of the payload */
                msg.AddRange(length);

                /* Add payload */
                msg.Add((byte)day);
                msg.Add((byte)month);
                msg.Add((byte)year);
            }

            return msg.ToArray();
        }

        private byte[] MakeCheckDeviceReadyMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            /* Add header to the message stream */
            //msg.AddRange(MSG_HEADER);

            /* Add type of the message */
            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_DEV_RDY);

            /* Add length of the payload */
            msg.AddRange(length);

            /* Add payload */
            //No payload required for this command;
            iosModeSet = false;
            pbWaitReady.Enabled = true;
            pbWaitReady.Visible = true;
            if (timer1.Enabled == false)
            {
                timer1.Elapsed += TimerElapsed;
                timer1.AutoReset = true;
                this.StartRaisingTimerEvent();
            }
            return msg.ToArray();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            byte[] msgStream = Array.Empty<byte>();

            switch (cbCommand.SelectedItem.ToString())
            {
                case "Device connect":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeDeviceConnectMsg();
                    }
                    break;

                case "Device Meta Data Update":
                    {
                        set_textAndLabelToDefault(false);
                        string errTxt = "";
                        if (ValidateDeviceMetaParams(ref errTxt, cbCommand.SelectedItem.ToString()))
                        {
                            msgStream = MakeDeviceMetaDataUpdateMsg();
                        }
                        else
                        {
                            SetCmdDesc(errTxt, Color.Red);
                        }
                    }
                    break;

                case "Certificate Update Indication":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeCertificateUpdateMsg();
                    }
                    break;

                case "Set Device RTC":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeSetDeviceRtcMsg();
                    }
                    break;

                case "Read Telemetry Data":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeReadTelemetryDataMsg();
                    }
                    break;

                case "Erase External Flash Memory":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeEraseFlashMemoryMsg();
                    }
                    break;

                case "Read System Log":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeDeviceLogReadMsg();
                    }
                    break;

                case "Check Device Ready":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeCheckDeviceReadyMsg();
                    }
                    break;

                case "Read File":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeFileReadOperationMsg();
                    }
                    break;

                case "Write File":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeFileWriteOperationMsg();
                    }
                    break;

                case "update cert ready":
                    {
                        set_textAndLabelToDefault(false);
                        msgStream = MakeUpdateCertReadyMsg();
                    }
                    break;

                case "update cert-rootca":
                    {
                        set_textAndLabelToDefault(false);
                        string errTxt = "";
                        if (ValidateDeviceMetaParams(ref errTxt, cbCommand.SelectedItem.ToString()))
                        {
                            msgStream = MakeUpdateRootCaMsg();
                        }
                        else
                        {
                            SetCmdDesc(errTxt, Color.Red);
                        }
                    }
                    break;

                case "update cert-devchain":
                    {
                        set_textAndLabelToDefault(false);
                        string errTxt = "";
                        if (ValidateDeviceMetaParams(ref errTxt, cbCommand.SelectedItem.ToString()))
                        {
                            msgStream = MakeUpdateCertDevChainMsg();
                        }
                        else
                        {
                            SetCmdDesc(errTxt, Color.Red);
                        }
                    }
                    break;

                case "update cert-devkey":
                    {
                        set_textAndLabelToDefault(false);
                        string errTxt = "";
                        if (ValidateDeviceMetaParams(ref errTxt, cbCommand.SelectedItem.ToString()))
                        {
                            msgStream = MakeUpdateCertDevKeyMsg();
                        }
                        else
                        {
                            SetCmdDesc(errTxt, Color.Red);
                        }
                    }
                    break;

                default:
                    break;
            }
            try
            {
                if ((msgStream != null) && msgStream.Length > 0)
                {
                    string strng = Encoding.ASCII.GetString(msgStream);
                    serialPortObj.Write(msgStream, 0, msgStream.Length);
                    lbSentCmd.Visible = true;

                }
            }
            catch (InvalidOperationException e1)
            {
                txtRecvMsg.AppendText("\n");
                Color oldColor = txtRecvMsg.ForeColor;
                txtRecvMsg.ForeColor = Color.Red;
                txtRecvMsg.AppendText(e1.Message);
                txtRecvMsg.ForeColor = oldColor;
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            timer1.Close();
            serialPortObj.Close();
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            StopRaisingEvent();
            pbWaitReady.Visible = false;
            lbResult.Visible = false;
            txtRecvMsg.Text = string.Empty;
            lbResult.Text = "";
            lbStringBytes.Text = "0 bytes";
            pageStillRemainig = false;
            totalBytesRead = 0;
            dataSentCount = 0;
        }

        private void btnSelectRootCACert_Click(object sender, EventArgs e)
        {
            if (System.Windows.Forms.DialogResult.OK == openFileCert.ShowDialog())
            {
                lbRootCAFileName.Text = openFileCert.FileName;
                lbRootCAFileName.ForeColor = System.Drawing.Color.DimGray;
                lbRootCAFileName.Visible = true;
            }
            else
            {
                lbRootCAFileName.Text = "No file selected";
                lbRootCAFileName.Visible = true;
            }
        }

        private void btnSelectDevChainCert_Click(object sender, EventArgs e)
        {
            if (System.Windows.Forms.DialogResult.OK == openFileCert.ShowDialog())
            {
                lbDevChainCertFileName.Text = openFileCert.FileName;
                lbDevChainCertFileName.ForeColor = System.Drawing.Color.DimGray;
                lbDevChainCertFileName.Visible = true;
            }
            else
            {
                lbDevChainCertFileName.Text = "No file selected";
                lbDevChainCertFileName.Visible = true;
            }
        }

        private void btnSelectDevKeyCert_Click(object sender, EventArgs e)
        {
            if (System.Windows.Forms.DialogResult.OK == openFileCert.ShowDialog())
            {
                lbDevKeyCertFileName.Text = openFileCert.FileName;
                lbDevKeyCertFileName.ForeColor = System.Drawing.Color.DimGray;
                lbDevKeyCertFileName.Visible = true;
            }
            else
            {
                lbDevKeyCertFileName.Text = "No file selected";
                lbDevKeyCertFileName.Visible = true;
            }
        }

        private void btnSelectFwImage_Click(object sender, EventArgs e)
        {
            if (System.Windows.Forms.DialogResult.OK == openFileCert.ShowDialog())
            {
                lbFwImageFileName.Text = openFileCert.FileName;
                lbFwImageFileName.Visible = true;
            }
            else
            {
                lbFwImageFileName.Text = "No file selected";
                lbFwImageFileName.Visible = true;
            }
        }

        private void cbLogDataDatePicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbLogDataDatePicker.SelectedItem.ToString())
            {
                case "All Data":
                    if (cbCommand.SelectedItem.ToString() == "Write File")
                    {
                    }
                    else
                    {
                        dtpDateTime.Visible = false;
                        dtpDateTime.Enabled = false;
                    }
                    break;

                case "Select Single Day...":
                    if (cbCommand.SelectedItem.ToString() == "Write File")
                    {
                    }
                    else
                    {
                        dtpDateTime.Format = DateTimePickerFormat.Custom;
                        dtpDateTime.CustomFormat = "MM/dd/yyyy hh:mm:ss";
                        dtpDateTime.Value = DateTime.Today;
                        dtpDateTime.Visible = true;
                        dtpDateTime.Enabled = true;
                    }
                    break;

                default:
                    break;
            }
            set_textAndLabelToDefault(false);
        }

        private void cbSelectFileType_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private byte[] MakeFileReadOperationMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };
            /* Add payload */
            //No payload required for this command;

            if (cbSelectFileType.SelectedItem.ToString() == "File Type Rec")
            {
                //switch (cbSelectFileMode.SelectedItem.ToString())
                switch (cbLogDataDatePicker.SelectedItem.ToString())
                {
                    case "All Data":
                        /* Add type of the message */
                        msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_REC_ALL);
                        //MessageBox.Show("read op rec Read-Write all files");
                        msg.AddRange(length);

                        break;

                    case "Select Single Day...":
                        /* Add type of the message */
                        msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_REC_BY_DATE);
                        /* Add type of the message */
                        //msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_SYS_LOG_BY_DATE);
                        length[0] = 0;
                        length[1] = 3; /* 3 bytes of payload */

                        int day = dtpDateTime.Value.Day;
                        int month = dtpDateTime.Value.Month;
                        int year = dtpDateTime.Value.Year;
                        year -= 2000; /* Year value is assumed to be based on year 2000 */

                        /* Add length of the payload */
                        msg.AddRange(length);

                        /* Add payload */
                        msg.Add((byte)day);
                        msg.Add((byte)month);
                        msg.Add((byte)year);
                        //MessageBox.Show("read op rec Read-Write day files");
                        break;

                    default:
                        break;
                }

            }
            else if (cbSelectFileType.SelectedItem.ToString() == "File Type Log")
            {
                switch (cbLogDataDatePicker.SelectedItem.ToString())
                {
                    case "All Data":
                        /* Add type of the message */
                        msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_DEV_RDY);
                        msg.AddRange(length);
                        //MessageBox.Show("read op log Read-Write all files");
                        break;

                    case "Select Single Day...":
                        /* Add type of the message */
                        msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_DEV_RDY);
                        msg.AddRange(length);
                        //MessageBox.Show("read op log Read-Write day files");
                        break;

                    default:
                        break;
                }
            }
            /* Add length of the payload */
            //msg.AddRange(length);

            //MessageBox.Show("read op send message");

            return msg.ToArray();
        }

        private byte[] MakeDeviceConnectMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            /* Add type of the message */
            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_DEV_CONNECT);

            /* Add length of the payload */
            msg.AddRange(length);

            lbDevKeyCertFileName.Text = String.Empty;
            pbWaitReady.Enabled = true;
            pbWaitReady.Visible = true;
            lbAlert.Text = "SETTING IOS MODE, PLEASE WAIT !!!";
            lbAlert.ForeColor = Color.Red;
            lbAlert.Enabled = true;
            lbAlert.Visible = true;

            return msg.ToArray();
        }

        private byte[] MakeUpdateCertReadyMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            /* Add header to the message stream */
            //msg.AddRange(MSG_HEADER);

            /* Add type of the message */
            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_CONFIG_UPDATE_CERTS_READY);

            /* Add length of the payload */
            msg.AddRange(length);

            /* Add payload */
            //No payload required for this command;
            lbSentCmd.Text = "CERT RDY";

            return msg.ToArray();
        }

        private byte[] MakeUpdateRootCaMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            try
            {
                rootCAFileSize = (UInt32)(new FileInfo(lbRootCAFileName.Text).Length);

                msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_CONFIG_UPDATE_CERT_ROOTCA);

                length[1] = (byte)(rootCAFileSize);
                length[0] = (byte)(rootCAFileSize >> 8);
                msg.AddRange(length);

                byte[] data = File.ReadAllBytes(openFileCert.FileName);
                lbRootCAFileName.Text = openFileCert.FileName;
                lbRootCAFileName.ForeColor = Color.DimGray;
                msg.AddRange(data);
            }
            catch (Exception ex)
            {
                lbRootCAFileName.Text = "File not found: " + ex.Message;
                lbRootCAFileName.ForeColor = Color.Red;
                return null;
            }

            msg.AddRange(UInt32ToNetworkByteOrder(rootCAFileSize));
            certUpdateMsg = msg.ToArray();

            certUpdate = true;
            pbWaitReady.Enabled = true;
            pbWaitReady.Visible = true;
            lbAlert.Text = "UPDATING ROOT-CA, PLEASE WAIT!!!";
            lbAlert.ForeColor = Color.Red;
            lbAlert.Enabled = true;
            lbAlert.Visible = true;

            return MakeUpdateCertReadyMsg();
        }

        private byte[] MakeUpdateCertDevChainMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };
            try
            {
                deviceChainCertFileSize = (UInt32)(new FileInfo(lbDevChainCertFileName.Text).Length);

                msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_CONFIG_UPDATE_CERT_DEVCHAIN);

                length[1] = (byte)(deviceChainCertFileSize);
                length[0] = (byte)(deviceChainCertFileSize >> 8);
                msg.AddRange(length);

                byte[] data = File.ReadAllBytes(openFileCert.FileName);
                lbDevChainCertFileName.Text = openFileCert.FileName;
                lbDevChainCertFileName.ForeColor = Color.DimGray;
                msg.AddRange(data);
            }
            catch (Exception ex)
            {
                lbDevChainCertFileName.Text = "File not found: " + ex.Message;
                lbDevChainCertFileName.ForeColor = Color.Red;
                return null;
            }

            msg.AddRange(UInt32ToNetworkByteOrder(deviceChainCertFileSize));

            certUpdateMsg = msg.ToArray();

            certUpdate = true;
            pbWaitReady.Enabled = true;
            pbWaitReady.Visible = true;
            lbAlert.Text = "UPDATING DEVICE-CHAIN, PLEASE WAIT!!!";
            lbAlert.ForeColor = Color.Red;
            lbAlert.Enabled = true;
            lbAlert.Visible = true;

            return MakeUpdateCertReadyMsg();
        }

        private byte[] MakeUpdateCertDevKeyMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };

            try
            {
                deviceKeyCertFileSize = (UInt32)(new FileInfo(lbDevKeyCertFileName.Text).Length);

                msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_CONFIG_UPDATE_CERT_DEVKEY);

                length[1] = (byte)(deviceKeyCertFileSize);
                length[0] = (byte)(deviceKeyCertFileSize >> 8);
                msg.AddRange(length);

                byte[] data = File.ReadAllBytes(openFileCert.FileName);
                lbDevKeyCertFileName.Text = openFileCert.FileName;
                lbDevKeyCertFileName.ForeColor = Color.DimGray;
                msg.AddRange(data);
            }
            catch (Exception ex)
            {
                lbDevKeyCertFileName.Text = "File not found: " + ex.Message;
                lbDevKeyCertFileName.ForeColor = Color.Red;
                return null;
            }

            msg.AddRange(UInt32ToNetworkByteOrder(deviceKeyCertFileSize));

            certUpdateMsg = msg.ToArray();

            certUpdate = true;
            pbWaitReady.Enabled = true;
            pbWaitReady.Visible = true;
            lbAlert.Text = "UPDATING DEVICE-KEY, PLEASE WAIT!!!";
            lbAlert.ForeColor = Color.Red;
            lbAlert.Enabled = true;
            lbAlert.Visible = true;

            return MakeUpdateCertReadyMsg();
        }

        private byte[] MakeFileWriteOperationMsg()
        {
            List<byte> msg = new List<byte>();
            byte[] length = new byte[2] { 0, 0 };
            // byte[] fileBytes;
            byte[] data = new byte[2048];
            lbResult.Text = "";
            lbResult.Visible = false;


            /* Add payload */
            //No payload required for this command;
            try
            {
                if ((cbSelectFileType.SelectedItem != null) && (cbSelectFileType.SelectedItem.ToString() == "File Type Rec"))
                {
                    switch (cbLogDataDatePicker.SelectedItem.ToString())
                    {
                        case "Select Single Day...":

                        case "All Data":
                            /* Add type of the message */
                            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_WR_REC_ENTRY);
                            //MessageBox.Show("write op rec Read-Write all files");
                            break;

                        default:
                            break;
                    }

                }
                else if (cbSelectFileType.SelectedItem.ToString() == "File Type Log")
                {
                    switch (cbLogDataDatePicker.SelectedItem.ToString())
                    {
                        case "All files":
                            /* Add type of the message */
                            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_DEV_RDY);
                            //MessageBox.Show("write op log Read-Write all files");
                            break;

                        case "Single day file":
                            /* Add type of the message */
                            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_DEV_RDY);

                            //*************************************************************************

                            /* Add type of the message */
                            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_RD_SYS_LOG_BY_DATE);
                            length[0] = 0;
                            length[1] = 3; /* 3 bytes of payload */

                            int day = dtpDateTime.Value.Day;
                            int month = dtpDateTime.Value.Month;
                            int year = dtpDateTime.Value.Year;
                            year -= 2000; /* Year value is assumed to be based on year 2000 */

                            /* Add length of the payload */
                            msg.AddRange(length);

                            /* Add payload */
                            msg.Add((byte)day);
                            msg.Add((byte)month);
                            msg.Add((byte)year);

                            //****************************************************************************

                            //MessageBox.Show("write op log Read-Write day files");
                            break;

                        default:
                            break;
                    }
                }


                if ((cbSelectInputMethod.SelectedItem != null) && (cbSelectInputMethod.SelectedItem.ToString() == "Upload File"))
                {
                    string filePath = openUploadFile.FileName;
                    if (File.Exists(filePath))
                    {
                        ulong fileLength = (ulong)new FileInfo(filePath).Length;
                        int bytesRead = 0;
                        FileStream fs = new FileStream(filePath, FileMode.Open);
                        if ((cbLogDataDatePicker.SelectedItem.ToString() == "Select Single Day...")
                            || ((cbLogDataDatePicker.SelectedItem.ToString() == "All Data") && fileLength <= 2048)
                            )
                        {
                            bytesRead = fs.Read(data, 0, 2048);
                            length[1] = (byte)(data.Length);
                            length[0] = (byte)(data.Length >> 8);
                            msg.AddRange(length);
                            msg.AddRange(data);
                            fs.Close();
                            filePath = "";
                        }
                        else
                        {
                            if (fileLength > 2048)
                            {
                                pageStillRemainig = true;
                                if (!isThreadRunning)
                                {
                                    isThreadRunning = true;
                                    threadShouldStop = false;
                                    btStop.Visible = true;
                                    Console.WriteLine("\n**new thread created**\n");
                                    Thread detachedThread = new Thread(() =>
                                    {
                                        Thread.CurrentThread.Name = "Detached Thread";
                                        Console.WriteLine(threadShouldStop ? "threadShouldStop bef while=true" :
                                            "threadShouldStop bef while=false");
                                        ulong totalBytesReadInThread = 0;
                                        int bytesReadInThread = 0;
                                        while (!threadShouldStop)
                                        {
                                            Console.WriteLine("dataSentCount = " + dataSentCount.ToString());
                                            if (!pageStillRemainig || cbCommand.SelectedItem.ToString() != "Write File"
                                                || cbLogDataDatePicker.SelectedItem.ToString() != "All Data"
                                                || cbSelectInputMethod.SelectedItem.ToString() != "Upload File")
                                            {
                                                isThreadRunning = false;
                                                threadShouldStop = false;
                                                filePath = "";
                                                Console.WriteLine("\n## STOPPING THREAD ##");
                                                break;
                                            }
                                            else if (pageStillRemainig)
                                            {
                                                if (dataSentCount != 0)
                                                {
                                                    Console.WriteLine("\n waiting for release with count..." + mySemaphore.CurrentCount.ToString());
                                                    mySemaphore.Wait();
                                                }
                                                Console.WriteLine("\n wait over, new count is " + mySemaphore.CurrentCount.ToString());
                                                //btnSend.PerformClick();
                                                fs.Seek((long)totalBytesReadInThread, SeekOrigin.Begin);
                                                bytesReadInThread = fs.Read(data, 0, 2048);
                                                length[1] = (byte)(bytesReadInThread);
                                                length[0] = (byte)(bytesReadInThread >> 8);
                                                msg.AddRange(length);
                                                msg.AddRange(data);
                                                string strng = Encoding.ASCII.GetString(data);
                                                txtRecvMsg.Text = strng;
                                                txtRecvMsg.Visible = true;
                                                if (bytesReadInThread < 2048)
                                                {
                                                    pageStillRemainig = false;
                                                    threadShouldStop = true;
                                                    totalBytesRead = 0;
                                                }
                                                if (msg.ToArray().Length > 0)
                                                {
                                                    Console.WriteLine("\n bytes read = " + bytesReadInThread.ToString());
                                                    Console.WriteLine("\n total bytes read = " + totalBytesReadInThread.ToString());
                                                    serialPortObj.Write(msg.ToArray(), 0, msg.ToArray().Length);
                                                    dataSentCount++;
                                                    lbResult.Visible = false;
                                                }
                                            }
                                            msg.Clear();
                                            msg.Add((byte)ConfigCmdTypeId.MSG_CH_MODBUS_WR_REC_ENTRY);
                                            lbFwImageFileName.Visible = true;
                                            totalBytesReadInThread = totalBytesReadInThread + (ulong)bytesReadInThread;
                                            string byteSent = totalBytesReadInThread.ToString();
                                            string byteRemaining = (fileLength - totalBytesRead).ToString();
                                            string pageWritten = dataSentCount.ToString();
                                            lbFwImageFileName.Text = "Bytes Sent = " + byteSent + "\n" + "Bytes Remaining = " + byteRemaining + "\n" + "Pages Written = " + pageWritten;
                                            Console.WriteLine(threadShouldStop ? "threadShouldStop=true" : "threadShouldStop=false");
                                            Console.WriteLine(pageStillRemainig ? "pageStillRemainig=true" : "pageStillRemainig=false");
                                        }
                                        mySemaphore.Dispose();
                                        mySemaphore = new SemaphoreSlim(0, 1);
                                        isThreadRunning = threadShouldStop = false;
                                        btStop.Visible = false;
                                        filePath = "";
                                        fs.Close();
                                    });

                                    detachedThread.IsBackground = true;
                                    detachedThread.Start();
                                }
                            }
                            return null;
                        }
                        //msg.AddRange(fileBytes);
                    }
                }
                else if ((cbSelectInputMethod.SelectedItem != null) && (cbSelectInputMethod.SelectedItem.ToString() == "Input Text"))
                {
                    //lbResult.Text = "";
                    //lbResult.Visible = false;
                    // Read the text from the textbox
                    string text = txtRecvMsg.Text;
                    ushort stringLength = (ushort)text.Length;
                    if (stringLength <= 2048)
                    {
                        //substring = text; // Use the entire string if its length is less than 2048
                        length[0] = (byte)(stringLength >> 8);
                        length[1] = (byte)stringLength;
                    }
                    else
                    {
                        text = text.Substring(0, 2048);
                        stringLength = (ushort)text.Length;
                        length[0] = (byte)(stringLength >> 8);
                        length[1] = (byte)stringLength;
                        MessageBox.Show("message length exceeds limit 2048, \n Trimming till 2048 bytes");
                        txtRecvMsg.Text = text;
                    }
                    byte[] textData = System.Text.Encoding.ASCII.GetBytes(text);
                    msg.AddRange(textData);
                }
                else
                {
                    MessageBox.Show("Select one of the input method!!");
                }
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show(ex + "\nSelect proper values");
            }

            return msg.ToArray();
        }

        private void txtRecvMsg_TextChanged(object sender, EventArgs e)
        {
            // if (cbSelectInputMethod.Enabled == false)
            {
                // Get the text from the text box
                string text = txtRecvMsg.Text;

                // Get the number of bytes of the text using the UTF-8 encoding
                int byteCount = System.Text.Encoding.UTF8.GetByteCount(text);

                // Display the byte count in a label
                lbStringBytes.Text = byteCount.ToString() + " bytes";
            }
        }

        private void selectInputMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbSelectInputMethod.SelectedItem.ToString())
            {
                case "Upload File":
                    txtRecvMsg.ReadOnly = true;
                    if (System.Windows.Forms.DialogResult.OK == openUploadFile.ShowDialog())
                    {
                        // Get the file info for the selected file
                        FileInfo fileInfo = new FileInfo(openUploadFile.FileName);

                        // Get the file size in bytes
                        long fileSizeInBytes = fileInfo.Length;

                        lbFwImageFileName.Text = openUploadFile.FileName + " " + fileSizeInBytes.ToString() + " bytes";
                        lbFwImageFileName.Visible = true;
                    }
                    else
                    {
                        lbFwImageFileName.Text = "No file selected";
                        lbFwImageFileName.Visible = true;
                    }
                    break;

                case "Input Text":
                    txtRecvMsg.ReadOnly = false;
                    lbFwImageFileName.Text = "";
                    lbFwImageFileName.Visible = false;

                    break;

                default:
                    MessageBox.Show("Select one of the input method!!");
                    break;
            }
            set_textAndLabelToDefault(false);
        }

        private void saveFile_Click(object sender, EventArgs e)
        {
            string filePath;
            //OpenFileDialog saveFile = new OpenFileDialog();
            SaveFileDialog saveFile = new SaveFileDialog();
            // Set the default file name and extension
            saveFile.FileName = "MyFile.txt";
            saveFile.DefaultExt = "txt";

            // Display the dialog box and get the result
            DialogResult result = saveFile.ShowDialog();

            if (result == DialogResult.OK)
            {
                filePath = saveFile.FileName;
                // Write the text to the file

                string text = txtRecvMsg.Text;

                // Write the text to the file
                File.WriteAllText(filePath, text);
            }
        }

        private void ConnForm_Load(object sender, EventArgs e)
        {

        }

        private void btGetSize_Click(object sender, EventArgs e)
        {
            // Get the text from the text box
            string text = txtRecvMsg.Text;

            // Get the number of bytes of the text using the UTF-8 encoding
            int byteCount = System.Text.Encoding.UTF8.GetByteCount(text);

            // Display the byte count in a label
            lbStringBytes.Text = byteCount.ToString() + " bytes";
        }

        private void lbResult_Click(object sender, EventArgs e)
        {

        }

        // Event handler method to be called when the VisibleChanged event occurs
        /*        private void LbResult_VisibleChanged(object sender, EventArgs e)
                {
                    // Check if the Visible property of the control is now true
                    if (lbResult.Visible)
                    {
                        if ((pageStillRemainig == true)
                            && (cbLogDataDatePicker.SelectedItem.ToString() == "All Data")
                            && (cbCommand.SelectedItem.ToString() == "Write File"))
                        {
                            Thread.Sleep(2000);
                            Console.WriteLine("\ncurrent count before release " + mySemaphore.CurrentCount.ToString());
                            mySemaphore.Release();
                            Console.WriteLine("\ncurrent count after release " + mySemaphore.CurrentCount.ToString());
                        }
                    }
                }*/

        private void btStop_Click(object sender, EventArgs e)
        {
            threadShouldStop = true;
            pageStillRemainig = false;
            isThreadRunning = false;
            btStop.Visible = false;
        }

        private void decoderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //decoderBox.Add(new DecodeForm(null, 0));
            DecodeForm decoderForm = new DecodeForm();
            decoderForm.Show();
        }

        private void lbCmdDesc_Click(object sender, EventArgs e)
        {

        }

        private void pbWaitReady_Click(object sender, EventArgs e)
        {

        }

        private void lbResult_Click_1(object sender, EventArgs e)
        {

        }

        private void lbSentCmd_Click(object sender, EventArgs e)
        {

        }
    }
}
