﻿using System.Diagnostics;
using System;
using System.Timers;
using System.Diagnostics.Eventing.Reader;
using System.Threading;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using System.Net.Security;

namespace SerialReader
{
    public partial class ConnForm
    {
        public delegate void MyTimerEvent_Handler(object sender, EventArgs e);
        private System.Timers.Timer timer1;

        public void StartRaisingTimerEvent()
        {
            Console.WriteLine("\n**timer starting**\n");
            timer1.Start();
            lbDevKeyCertFileName.Text = "WAITING FOR CONNECTION !!!";
            lbDevKeyCertFileName.ForeColor = System.Drawing.Color.Red;
            cbCommand.Enabled = false;
        }

        public void StopRaisingEvent()
        {
            timer1.Stop();
            lbDevKeyCertFileName.Text = string.Empty;
            cbCommand.Enabled = true;
        }

        //private void TimerElapsed(object sender, ElapsedEventArgs e)
        //{
        //    Console.WriteLine("timer triggered!");
        //OnMyTimerEventTriggered(EventArgs.Empty); // When time is elapsed, this function is called which in turn raises an event named MyTimerEventTriggered.
        //}

        //protected virtual void OnMyTimerEventTriggered(EventArgs e)
        //{
        //    MyTimerEventTriggered?.Invoke(this, e);// This is the event that is actually raised
        //}

        //public void HandleTimerTriggerEvent(object sender, EventArgs e)
        //{
        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            Console.WriteLine("Event handled!");
            if (serialResp == "Pass")
            {
                StopRaisingEvent();
                lbDevKeyCertFileName.Text = "CONNECTED !!!";
                lbDevKeyCertFileName.ForeColor = System.Drawing.Color.Green;
                pbWaitReady.Visible = false;
                pbWaitReady.Enabled = false;
                isReady=true;
            }
            else if((cbCommand.SelectedItem.ToString() == "Check Device Ready") && (serialResp != "Pass"))
            {
                Console.WriteLine("**clicked again**!");
                btnSend.PerformClick();
            }
            else if ((cbCommand.SelectedItem.ToString())=="")
            {

            }
        }

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        //Thread loopThread = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (serialPortObj.IsOpen)
            {
                serialPortObj.Close();
            }

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Timers.Timer();
            this.lbCommand = new System.Windows.Forms.Label();
            this.cbCommand = new System.Windows.Forms.ComboBox();
            this.gbParams = new System.Windows.Forms.GroupBox();
            this.lbAlert = new System.Windows.Forms.Label();
            this.pbWaitReady = new System.Windows.Forms.PictureBox();
            this.lbSelectInputMethod = new System.Windows.Forms.Label();
            this.lbSelectFileType = new System.Windows.Forms.Label();
            this.cbSelectInputMethod = new System.Windows.Forms.ComboBox();
            this.cbSelectFileType = new System.Windows.Forms.ComboBox();
            this.numUDDeviceID = new System.Windows.Forms.NumericUpDown();
            this.numUDFwMinor = new System.Windows.Forms.NumericUpDown();
            this.numUDFwMajor = new System.Windows.Forms.NumericUpDown();
            this.cbLogDataDatePicker = new System.Windows.Forms.ComboBox();
            this.dtpDateTime = new System.Windows.Forms.DateTimePicker();
            this.lbFwVerMinor = new System.Windows.Forms.Label();
            this.lbFwVerMajor = new System.Windows.Forms.Label();
            this.lbDevID = new System.Windows.Forms.Label();
            this.lbFwVersion = new System.Windows.Forms.Label();
            this.lbFwImageFileName = new System.Windows.Forms.Label();
            this.btnSelectFwImage = new System.Windows.Forms.Button();
            this.lbDevKeyCertFileName = new System.Windows.Forms.Label();
            this.btnSelectDevKeyCert = new System.Windows.Forms.Button();
            this.lbDevChainCertFileName = new System.Windows.Forms.Label();
            this.btnSelectDevChainCert = new System.Windows.Forms.Button();
            this.lbRootCAFileName = new System.Windows.Forms.Label();
            this.btnSelectRootCACert = new System.Windows.Forms.Button();
            this.lbSentCmd = new System.Windows.Forms.Label();
            this.btnSend = new System.Windows.Forms.Button();
            this.gbRecvMsg = new System.Windows.Forms.GroupBox();
            this.lbStringBytes = new System.Windows.Forms.Label();
            this.txtRecvMsg = new System.Windows.Forms.TextBox();
            this.openFileCert = new System.Windows.Forms.OpenFileDialog();
            this.openUploadFile = new System.Windows.Forms.OpenFileDialog();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.serialPortObj = new System.IO.Ports.SerialPort(this.components);
            this.btnClear = new System.Windows.Forms.Button();
            this.lbCmdDesc = new System.Windows.Forms.Label();
            this.lbResult = new System.Windows.Forms.Label();
            this.saveFile = new System.Windows.Forms.Button();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.btStop = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.decoderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
            this.gbParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbWaitReady)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDDeviceID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDFwMinor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDFwMajor)).BeginInit();
            this.gbRecvMsg.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 3000D;
            this.timer1.SynchronizingObject = this;
            // 
            // lbCommand
            // 
            this.lbCommand.AutoSize = true;
            this.lbCommand.Location = new System.Drawing.Point(27, 56);
            this.lbCommand.Name = "lbCommand";
            this.lbCommand.Size = new System.Drawing.Size(72, 16);
            this.lbCommand.TabIndex = 0;
            this.lbCommand.Text = "Command:";
            // 
            // cbCommand
            // 
            this.cbCommand.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.cbCommand.BackColor = System.Drawing.Color.Gainsboro;
            this.cbCommand.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbCommand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCommand.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbCommand.ForeColor = System.Drawing.SystemColors.InfoText;
            this.cbCommand.FormattingEnabled = true;
            this.cbCommand.Items.AddRange(new object[] {
            "Select Command...",
            "Check Device Ready",
            "Device connect",
            "Device Meta Data Update",
            "Set Device RTC",
            "Certificate Update Indication",
            "Read Telemetry Data",
            "Read System Log",
            "Session Close",
            "Erase External Flash Memory",
            "Read File",
            "Write File",
            "update cert-rootca",
            "update cert-devchain",
            "update cert-devkey"});
            this.cbCommand.Location = new System.Drawing.Point(136, 53);
            this.cbCommand.Name = "cbCommand";
            this.cbCommand.Size = new System.Drawing.Size(294, 24);
            this.cbCommand.TabIndex = 1;
            this.cbCommand.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // gbParams
            // 
            this.gbParams.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbParams.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gbParams.BackColor = System.Drawing.Color.GhostWhite;
            this.gbParams.Controls.Add(this.lbAlert);
            this.gbParams.Controls.Add(this.pbWaitReady);
            this.gbParams.Controls.Add(this.lbSelectInputMethod);
            this.gbParams.Controls.Add(this.lbSelectFileType);
            this.gbParams.Controls.Add(this.cbSelectInputMethod);
            this.gbParams.Controls.Add(this.cbSelectFileType);
            this.gbParams.Controls.Add(this.numUDDeviceID);
            this.gbParams.Controls.Add(this.numUDFwMinor);
            this.gbParams.Controls.Add(this.numUDFwMajor);
            this.gbParams.Controls.Add(this.cbLogDataDatePicker);
            this.gbParams.Controls.Add(this.dtpDateTime);
            this.gbParams.Controls.Add(this.lbFwVerMinor);
            this.gbParams.Controls.Add(this.lbFwVerMajor);
            this.gbParams.Controls.Add(this.lbDevID);
            this.gbParams.Controls.Add(this.lbFwVersion);
            this.gbParams.Controls.Add(this.lbFwImageFileName);
            this.gbParams.Controls.Add(this.btnSelectFwImage);
            this.gbParams.Controls.Add(this.lbDevKeyCertFileName);
            this.gbParams.Controls.Add(this.btnSelectDevKeyCert);
            this.gbParams.Controls.Add(this.lbDevChainCertFileName);
            this.gbParams.Controls.Add(this.btnSelectDevChainCert);
            this.gbParams.Controls.Add(this.lbRootCAFileName);
            this.gbParams.Controls.Add(this.btnSelectRootCACert);
            this.gbParams.Location = new System.Drawing.Point(30, 118);
            this.gbParams.Name = "gbParams";
            this.gbParams.Size = new System.Drawing.Size(828, 367);
            this.gbParams.TabIndex = 2;
            this.gbParams.TabStop = false;
            this.gbParams.Text = "Parameters";
            // 
            // lbAlert
            // 
            this.lbAlert.AutoSize = true;
            this.lbAlert.Location = new System.Drawing.Point(282, 146);
            this.lbAlert.Name = "lbAlert";
            this.lbAlert.Size = new System.Drawing.Size(0, 16);
            this.lbAlert.TabIndex = 32;
            // 
            // pbWaitReady
            // 
            this.pbWaitReady.Enabled = false;
            this.pbWaitReady.Image = global::SerialReader.Properties.Resources.Triangles_indicator;
            this.pbWaitReady.Location = new System.Drawing.Point(339, 167);
            this.pbWaitReady.Name = "pbWaitReady";
            this.pbWaitReady.Size = new System.Drawing.Size(64, 64);
            this.pbWaitReady.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbWaitReady.TabIndex = 20;
            this.pbWaitReady.TabStop = false;
            this.pbWaitReady.Visible = false;
            this.pbWaitReady.Click += new System.EventHandler(this.pbWaitReady_Click);
            // 
            // lbSelectInputMethod
            // 
            this.lbSelectInputMethod.AutoSize = true;
            this.lbSelectInputMethod.Enabled = false;
            this.lbSelectInputMethod.Location = new System.Drawing.Point(271, 120);
            this.lbSelectInputMethod.Name = "lbSelectInputMethod";
            this.lbSelectInputMethod.Size = new System.Drawing.Size(127, 16);
            this.lbSelectInputMethod.TabIndex = 31;
            this.lbSelectInputMethod.Text = "Select Input Method:";
            this.lbSelectInputMethod.Visible = false;
            // 
            // lbSelectFileType
            // 
            this.lbSelectFileType.AutoSize = true;
            this.lbSelectFileType.Enabled = false;
            this.lbSelectFileType.Location = new System.Drawing.Point(295, 58);
            this.lbSelectFileType.Name = "lbSelectFileType";
            this.lbSelectFileType.Size = new System.Drawing.Size(108, 16);
            this.lbSelectFileType.TabIndex = 30;
            this.lbSelectFileType.Text = "Select File Type:";
            this.lbSelectFileType.Visible = false;
            // 
            // cbSelectInputMethod
            // 
            this.cbSelectInputMethod.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbSelectInputMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSelectInputMethod.Enabled = false;
            this.cbSelectInputMethod.FormattingEnabled = true;
            this.cbSelectInputMethod.Items.AddRange(new object[] {
            "Upload File",
            "Input Text"});
            this.cbSelectInputMethod.Location = new System.Drawing.Point(425, 118);
            this.cbSelectInputMethod.Name = "cbSelectInputMethod";
            this.cbSelectInputMethod.Size = new System.Drawing.Size(160, 24);
            this.cbSelectInputMethod.TabIndex = 29;
            this.cbSelectInputMethod.Visible = false;
            this.cbSelectInputMethod.SelectedIndexChanged += new System.EventHandler(this.selectInputMethod_SelectedIndexChanged);
            // 
            // cbSelectFileType
            // 
            this.cbSelectFileType.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbSelectFileType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSelectFileType.FormattingEnabled = true;
            this.cbSelectFileType.Items.AddRange(new object[] {
            "File Type Rec"});
            this.cbSelectFileType.Location = new System.Drawing.Point(425, 54);
            this.cbSelectFileType.Name = "cbSelectFileType";
            this.cbSelectFileType.Size = new System.Drawing.Size(161, 24);
            this.cbSelectFileType.TabIndex = 24;
            this.cbSelectFileType.Visible = false;
            this.cbSelectFileType.SelectedIndexChanged += new System.EventHandler(this.cbSelectFileType_SelectedIndexChanged);
            // 
            // numUDDeviceID
            // 
            this.numUDDeviceID.BackColor = System.Drawing.Color.Wheat;
            this.numUDDeviceID.Enabled = false;
            this.numUDDeviceID.Location = new System.Drawing.Point(272, 296);
            this.numUDDeviceID.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.numUDDeviceID.Name = "numUDDeviceID";
            this.numUDDeviceID.Size = new System.Drawing.Size(242, 22);
            this.numUDDeviceID.TabIndex = 23;
            this.numUDDeviceID.Visible = false;
            // 
            // numUDFwMinor
            // 
            this.numUDFwMinor.BackColor = System.Drawing.Color.Wheat;
            this.numUDFwMinor.Enabled = false;
            this.numUDFwMinor.Location = new System.Drawing.Point(535, 249);
            this.numUDFwMinor.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numUDFwMinor.Name = "numUDFwMinor";
            this.numUDFwMinor.Size = new System.Drawing.Size(86, 22);
            this.numUDFwMinor.TabIndex = 22;
            this.numUDFwMinor.Visible = false;
            // 
            // numUDFwMajor
            // 
            this.numUDFwMajor.BackColor = System.Drawing.Color.Wheat;
            this.numUDFwMajor.Enabled = false;
            this.numUDFwMajor.Location = new System.Drawing.Point(303, 251);
            this.numUDFwMajor.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numUDFwMajor.Name = "numUDFwMajor";
            this.numUDFwMajor.Size = new System.Drawing.Size(86, 22);
            this.numUDFwMajor.TabIndex = 21;
            this.numUDFwMajor.Visible = false;
            // 
            // cbLogDataDatePicker
            // 
            this.cbLogDataDatePicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.cbLogDataDatePicker.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLogDataDatePicker.Enabled = false;
            this.cbLogDataDatePicker.FormattingEnabled = true;
            this.cbLogDataDatePicker.Items.AddRange(new object[] {
            "All Data",
            "Select Single Day..."});
            this.cbLogDataDatePicker.Location = new System.Drawing.Point(425, 86);
            this.cbLogDataDatePicker.Name = "cbLogDataDatePicker";
            this.cbLogDataDatePicker.Size = new System.Drawing.Size(161, 24);
            this.cbLogDataDatePicker.TabIndex = 19;
            this.cbLogDataDatePicker.Visible = false;
            this.cbLogDataDatePicker.SelectedIndexChanged += new System.EventHandler(this.cbLogDataDatePicker_SelectedIndexChanged);
            // 
            // dtpDateTime
            // 
            this.dtpDateTime.Enabled = false;
            this.dtpDateTime.Location = new System.Drawing.Point(424, 144);
            this.dtpDateTime.MaxDate = new System.DateTime(2050, 12, 31, 0, 0, 0, 0);
            this.dtpDateTime.Name = "dtpDateTime";
            this.dtpDateTime.Size = new System.Drawing.Size(202, 22);
            this.dtpDateTime.TabIndex = 18;
            this.dtpDateTime.Value = new System.DateTime(2023, 1, 16, 0, 0, 0, 0);
            this.dtpDateTime.Visible = false;
            // 
            // lbFwVerMinor
            // 
            this.lbFwVerMinor.AutoSize = true;
            this.lbFwVerMinor.Enabled = false;
            this.lbFwVerMinor.Location = new System.Drawing.Point(415, 254);
            this.lbFwVerMinor.Name = "lbFwVerMinor";
            this.lbFwVerMinor.Size = new System.Drawing.Size(92, 16);
            this.lbFwVerMinor.TabIndex = 16;
            this.lbFwVerMinor.Text = "Minor Version:";
            this.lbFwVerMinor.Visible = false;
            // 
            // lbFwVerMajor
            // 
            this.lbFwVerMajor.AutoSize = true;
            this.lbFwVerMajor.Enabled = false;
            this.lbFwVerMajor.Location = new System.Drawing.Point(174, 254);
            this.lbFwVerMajor.Name = "lbFwVerMajor";
            this.lbFwVerMajor.Size = new System.Drawing.Size(93, 16);
            this.lbFwVerMajor.TabIndex = 14;
            this.lbFwVerMajor.Text = "Major Version:";
            this.lbFwVerMajor.Visible = false;
            // 
            // lbDevID
            // 
            this.lbDevID.AutoSize = true;
            this.lbDevID.Enabled = false;
            this.lbDevID.Location = new System.Drawing.Point(21, 301);
            this.lbDevID.Name = "lbDevID";
            this.lbDevID.Size = new System.Drawing.Size(69, 16);
            this.lbDevID.TabIndex = 12;
            this.lbDevID.Text = "Device ID:";
            this.lbDevID.Visible = false;
            // 
            // lbFwVersion
            // 
            this.lbFwVersion.AutoSize = true;
            this.lbFwVersion.Enabled = false;
            this.lbFwVersion.Location = new System.Drawing.Point(21, 254);
            this.lbFwVersion.Name = "lbFwVersion";
            this.lbFwVersion.Size = new System.Drawing.Size(114, 16);
            this.lbFwVersion.TabIndex = 11;
            this.lbFwVersion.Text = "Firmware Version:";
            this.lbFwVersion.Visible = false;
            // 
            // lbFwImageFileName
            // 
            this.lbFwImageFileName.AutoSize = true;
            this.lbFwImageFileName.Enabled = false;
            this.lbFwImageFileName.Location = new System.Drawing.Point(281, 203);
            this.lbFwImageFileName.Name = "lbFwImageFileName";
            this.lbFwImageFileName.Size = new System.Drawing.Size(40, 16);
            this.lbFwImageFileName.TabIndex = 10;
            this.lbFwImageFileName.Text = "None";
            this.lbFwImageFileName.Visible = false;
            // 
            // btnSelectFwImage
            // 
            this.btnSelectFwImage.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnSelectFwImage.Enabled = false;
            this.btnSelectFwImage.Location = new System.Drawing.Point(23, 197);
            this.btnSelectFwImage.Name = "btnSelectFwImage";
            this.btnSelectFwImage.Size = new System.Drawing.Size(232, 29);
            this.btnSelectFwImage.TabIndex = 9;
            this.btnSelectFwImage.Text = "Select Firmware Image...";
            this.btnSelectFwImage.UseVisualStyleBackColor = false;
            this.btnSelectFwImage.Visible = false;
            this.btnSelectFwImage.Click += new System.EventHandler(this.btnSelectFwImage_Click);
            // 
            // lbDevKeyCertFileName
            // 
            this.lbDevKeyCertFileName.AutoSize = true;
            this.lbDevKeyCertFileName.Location = new System.Drawing.Point(281, 146);
            this.lbDevKeyCertFileName.Name = "lbDevKeyCertFileName";
            this.lbDevKeyCertFileName.Size = new System.Drawing.Size(40, 16);
            this.lbDevKeyCertFileName.TabIndex = 8;
            this.lbDevKeyCertFileName.Text = "None";
            this.lbDevKeyCertFileName.Visible = false;
            // 
            // btnSelectDevKeyCert
            // 
            this.btnSelectDevKeyCert.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnSelectDevKeyCert.Enabled = false;
            this.btnSelectDevKeyCert.Location = new System.Drawing.Point(24, 140);
            this.btnSelectDevKeyCert.Name = "btnSelectDevKeyCert";
            this.btnSelectDevKeyCert.Size = new System.Drawing.Size(231, 29);
            this.btnSelectDevKeyCert.TabIndex = 7;
            this.btnSelectDevKeyCert.Text = "Select Device Key Certificate...";
            this.btnSelectDevKeyCert.UseVisualStyleBackColor = false;
            this.btnSelectDevKeyCert.Visible = false;
            this.btnSelectDevKeyCert.Click += new System.EventHandler(this.btnSelectDevKeyCert_Click);
            // 
            // lbDevChainCertFileName
            // 
            this.lbDevChainCertFileName.AutoSize = true;
            this.lbDevChainCertFileName.Enabled = false;
            this.lbDevChainCertFileName.Location = new System.Drawing.Point(281, 89);
            this.lbDevChainCertFileName.Name = "lbDevChainCertFileName";
            this.lbDevChainCertFileName.Size = new System.Drawing.Size(40, 16);
            this.lbDevChainCertFileName.TabIndex = 6;
            this.lbDevChainCertFileName.Text = "None";
            this.lbDevChainCertFileName.Visible = false;
            // 
            // btnSelectDevChainCert
            // 
            this.btnSelectDevChainCert.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnSelectDevChainCert.Location = new System.Drawing.Point(21, 84);
            this.btnSelectDevChainCert.Name = "btnSelectDevChainCert";
            this.btnSelectDevChainCert.Size = new System.Drawing.Size(234, 29);
            this.btnSelectDevChainCert.TabIndex = 5;
            this.btnSelectDevChainCert.Text = "Select Device Chain Certificate...";
            this.btnSelectDevChainCert.UseVisualStyleBackColor = false;
            this.btnSelectDevChainCert.Visible = false;
            this.btnSelectDevChainCert.Click += new System.EventHandler(this.btnSelectDevChainCert_Click);
            // 
            // lbRootCAFileName
            // 
            this.lbRootCAFileName.AutoSize = true;
            this.lbRootCAFileName.Enabled = false;
            this.lbRootCAFileName.Location = new System.Drawing.Point(281, 35);
            this.lbRootCAFileName.Name = "lbRootCAFileName";
            this.lbRootCAFileName.Size = new System.Drawing.Size(40, 16);
            this.lbRootCAFileName.TabIndex = 4;
            this.lbRootCAFileName.Text = "None";
            this.lbRootCAFileName.Visible = false;
            // 
            // btnSelectRootCACert
            // 
            this.btnSelectRootCACert.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnSelectRootCACert.Enabled = false;
            this.btnSelectRootCACert.Location = new System.Drawing.Point(20, 31);
            this.btnSelectRootCACert.Name = "btnSelectRootCACert";
            this.btnSelectRootCACert.Size = new System.Drawing.Size(235, 29);
            this.btnSelectRootCACert.TabIndex = 3;
            this.btnSelectRootCACert.Text = "Select Root CA Certificate...";
            this.btnSelectRootCACert.UseVisualStyleBackColor = false;
            this.btnSelectRootCACert.Visible = false;
            this.btnSelectRootCACert.Click += new System.EventHandler(this.btnSelectRootCACert_Click);
            // 
            // lbSentCmd
            // 
            this.lbSentCmd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSentCmd.AutoSize = true;
            this.lbSentCmd.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbSentCmd.Location = new System.Drawing.Point(950, 340);
            this.lbSentCmd.Name = "lbSentCmd";
            this.lbSentCmd.Size = new System.Drawing.Size(73, 16);
            this.lbSentCmd.TabIndex = 32;
            this.lbSentCmd.Text = "lbSentCmd";
            this.lbSentCmd.Click += new System.EventHandler(this.lbSentCmd_Click);
            // 
            // btnSend
            // 
            this.btnSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSend.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSend.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSend.Location = new System.Drawing.Point(955, 294);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(97, 43);
            this.btnSend.TabIndex = 3;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // gbRecvMsg
            // 
            this.gbRecvMsg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbRecvMsg.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gbRecvMsg.Controls.Add(this.lbStringBytes);
            this.gbRecvMsg.Controls.Add(this.txtRecvMsg);
            this.gbRecvMsg.Location = new System.Drawing.Point(30, 518);
            this.gbRecvMsg.Name = "gbRecvMsg";
            this.gbRecvMsg.Size = new System.Drawing.Size(828, 188);
            this.gbRecvMsg.TabIndex = 3;
            this.gbRecvMsg.TabStop = false;
            this.gbRecvMsg.Text = "Incoming Message";
            // 
            // lbStringBytes
            // 
            this.lbStringBytes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbStringBytes.AutoSize = true;
            this.lbStringBytes.Location = new System.Drawing.Point(737, 0);
            this.lbStringBytes.Name = "lbStringBytes";
            this.lbStringBytes.Size = new System.Drawing.Size(0, 16);
            this.lbStringBytes.TabIndex = 1;
            // 
            // txtRecvMsg
            // 
            this.txtRecvMsg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRecvMsg.Location = new System.Drawing.Point(5, 21);
            this.txtRecvMsg.Multiline = true;
            this.txtRecvMsg.Name = "txtRecvMsg";
            this.txtRecvMsg.ReadOnly = true;
            this.txtRecvMsg.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRecvMsg.Size = new System.Drawing.Size(805, 161);
            this.txtRecvMsg.TabIndex = 0;
            this.txtRecvMsg.TextChanged += new System.EventHandler(this.txtRecvMsg_TextChanged);
            // 
            // openFileCert
            // 
            this.openFileCert.FileName = "fileCert";
            // 
            // openUploadFile
            // 
            this.openUploadFile.FileName = "uploadFile";
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDisconnect.AutoEllipsis = true;
            this.btnDisconnect.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnDisconnect.BackColor = System.Drawing.Color.DarkGray;
            this.btnDisconnect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDisconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisconnect.ForeColor = System.Drawing.Color.White;
            this.btnDisconnect.Location = new System.Drawing.Point(933, 56);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(139, 36);
            this.btnDisconnect.TabIndex = 4;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = false;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnClear.BackColor = System.Drawing.Color.DarkGray;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(955, 619);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(97, 39);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lbCmdDesc
            // 
            this.lbCmdDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbCmdDesc.AutoSize = true;
            this.lbCmdDesc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbCmdDesc.Location = new System.Drawing.Point(26, 93);
            this.lbCmdDesc.Name = "lbCmdDesc";
            this.lbCmdDesc.Size = new System.Drawing.Size(457, 16);
            this.lbCmdDesc.TabIndex = 13;
            this.lbCmdDesc.Text = "Command Desc: Please select a command from the above dropdown menu";
            this.lbCmdDesc.Visible = false;
            this.lbCmdDesc.Click += new System.EventHandler(this.lbCmdDesc_Click);
            // 
            // lbResult
            // 
            this.lbResult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbResult.BackColor = System.Drawing.Color.FloralWhite;
            this.lbResult.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbResult.Location = new System.Drawing.Point(959, 379);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(93, 48);
            this.lbResult.TabIndex = 14;
            this.lbResult.Tag = "Rslt";
            this.lbResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbResult.Click += new System.EventHandler(this.lbResult_Click_1);
            // 
            // saveFile
            // 
            this.saveFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.saveFile.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.saveFile.BackColor = System.Drawing.Color.WhiteSmoke;
            this.saveFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveFile.Location = new System.Drawing.Point(955, 553);
            this.saveFile.Name = "saveFile";
            this.saveFile.Size = new System.Drawing.Size(97, 36);
            this.saveFile.TabIndex = 15;
            this.saveFile.Text = "Export";
            this.saveFile.UseVisualStyleBackColor = false;
            this.saveFile.Click += new System.EventHandler(this.saveFile_Click);
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // btStop
            // 
            this.btStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btStop.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btStop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btStop.Location = new System.Drawing.Point(955, 213);
            this.btStop.Name = "btStop";
            this.btStop.Size = new System.Drawing.Size(97, 41);
            this.btStop.TabIndex = 16;
            this.btStop.Text = "Stop";
            this.btStop.UseVisualStyleBackColor = true;
            this.btStop.Visible = false;
            this.btStop.Click += new System.EventHandler(this.btStop_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.decoderToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1150, 28);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // decoderToolStripMenuItem
            // 
            this.decoderToolStripMenuItem.Name = "decoderToolStripMenuItem";
            this.decoderToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.decoderToolStripMenuItem.Text = "Decoder";
            this.decoderToolStripMenuItem.Click += new System.EventHandler(this.decoderToolStripMenuItem_Click);
            // 
            // ConnForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1150, 724);
            this.Controls.Add(this.lbSentCmd);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lbCmdDesc);
            this.Controls.Add(this.saveFile);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.gbRecvMsg);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.btStop);
            this.Controls.Add(this.gbParams);
            this.Controls.Add(this.cbCommand);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.lbCommand);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ConnForm";
            this.Text = "OpenedConnection";
            this.Load += new System.EventHandler(this.ConnForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();
            this.gbParams.ResumeLayout(false);
            this.gbParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbWaitReady)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDDeviceID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDFwMinor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDFwMajor)).EndInit();
            this.gbRecvMsg.ResumeLayout(false);
            this.gbRecvMsg.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

/*        public void LoopThread()
        {
            while (true)
            {
*//*                Console.WriteLine("\nbtnSend_MethodName -->: " + btnSend_MethodName);
                Console.WriteLine("\nReadSerialDataMethoExecuted -->: " + ReadSerialDataMethoExecuted);*//*
                if(btnSend_MethodName == 1 && ReadSerialDataMethoExecuted == 1
                    && (cbLogDataDatePicker.SelectedItem.ToString() == "All Data")
                    && (cbCommand.SelectedItem.ToString() == "Write File")
                    && (cbLogDataDatePicker.SelectedItem != null) 
                    && (cbCommand.SelectedItem != null)
                    && pageStillRemainig == true) {
                    Console.WriteLine("\nbtnSend_MethodName -->: " + btnSend_MethodName);
                    Console.WriteLine("\nReadSerialDataMethoExecuted -->: " + ReadSerialDataMethoExecuted);
                    Thread.Sleep(3000);
                    Console.WriteLine("---------------------");
                    btnSend.PerformClick();
                    Console.WriteLine("**********************");
                } 
            }
        }*/

        #endregion

        /* Constants */
        private readonly byte[] MSG_HEADER = { 0xff, 0xff, 0x01, 0xff, 0xff, 0xff, 0xff, 0xff };
        private const byte ROOT_CA_TYPE = 2;
        private const byte DEVICE_CHAIN_TYPE = 3;
        private const byte DEVICE_KEY_TYPE = 4;
        private enum ConfigCmdTypeId : byte
        {
            /*            MSG_CH_MODBUS_INVALID = 0x10,
                        MSG_CH_MODBUS_DEV_RDY = 0x64,
                        MSG_CH_MODBUS_SET_DEV_META,
                        MSG_CH_MODBUS_SET_RTC,
                        MSG_CH_MODBUS_ERASE_EXT_FLASH,
                        MSG_CH_MODBUS_CONFIG_CERTS,
                        MSG_CH_MODBUS_RD_REC_BY_DATE,
                        MSG_CH_MODBUS_RD_REC_ALL,
                        MSG_CH_MODBUS_RD_SYS_LOG_BY_DATE,
                        MSG_CH_MODBUS_RD_SYS_LOG_ALL,
                        MSG_CH_MODBUS_WR_REC_ENTRY,
                        MSG_CH_MODBUS_EXIT,*/

            MSG_CH_MODBUS_INVALID = 0x10,
            MSG_CH_MODBUS_DEV_RDY = 0x64,
            MSG_CH_MODBUS_DEV_CONNECT,
            MSG_CH_MODBUS_SET_DEV_META,//dev_id, fw_ver, fw_sz, certs(rootca, chain & key) sz
            MSG_CH_MODBUS_SET_RTC,
            MSG_CH_MODBUS_CONFIG_CERTS,//config to modem

            MSG_CH_MODBUS_CONFIG_UPDATE_CERTS_READY = 105,
            MSG_CH_MODBUS_CONFIG_UPDATE_CERT_ROOTCA,
            MSG_CH_MODBUS_CONFIG_UPDATE_CERT_DEVCHAIN,
            MSG_CH_MODBUS_CONFIG_UPDATE_CERT_DEVKEY,

            MSG_CH_MODBUS_RD_REC_BY_DATE,
            MSG_CH_MODBUS_RD_REC_ALL,
            MSG_CH_MODBUS_RD_SYS_LOG_BY_DATE,
            MSG_CH_MODBUS_RD_SYS_LOG_ALL,
            MSG_CH_MODBUS_ACC_GYR_CALIBRATE,
            MSG_CH_MODBUS_ACC_GYR_SET_CONFIG,
            MSG_CH_MODBUS_WR_REC_ENTRY,
            MSG_CH_MODBUS_ERASE_EXT_FLASH,
            MSG_CH_MODBUS_EXIT
        };

        private System.Windows.Forms.Label lbCommand;
        private System.Windows.Forms.ComboBox cbCommand;
        private System.Windows.Forms.GroupBox gbParams;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.GroupBox gbRecvMsg;
        public System.Windows.Forms.TextBox txtRecvMsg;
        private System.Windows.Forms.OpenFileDialog openFileCert;
        private System.Windows.Forms.OpenFileDialog openUploadFile;
        private System.Windows.Forms.Button btnSelectRootCACert;
        private System.Windows.Forms.Label lbRootCAFileName;
        private System.Windows.Forms.Button btnDisconnect;
        private System.IO.Ports.SerialPort serialPortObj;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lbDevKeyCertFileName;
        private System.Windows.Forms.Button btnSelectDevKeyCert;
        private System.Windows.Forms.Label lbDevChainCertFileName;
        private System.Windows.Forms.Button btnSelectDevChainCert;
        private System.Windows.Forms.Label lbDevID;
        private System.Windows.Forms.Label lbFwVersion;
        private System.Windows.Forms.Label lbFwImageFileName;
        private System.Windows.Forms.Button btnSelectFwImage;
        private System.Windows.Forms.Label lbCmdDesc;
        private System.Windows.Forms.Label lbFwVerMinor;
        private System.Windows.Forms.Label lbFwVerMajor;
        private System.Windows.Forms.ComboBox cbLogDataDatePicker;
        private System.Windows.Forms.DateTimePicker dtpDateTime;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.NumericUpDown numUDFwMinor;
        private System.Windows.Forms.NumericUpDown numUDFwMajor;
        private System.Windows.Forms.NumericUpDown numUDDeviceID;
        private System.Windows.Forms.ComboBox cbSelectFileType;
        private System.Windows.Forms.ComboBox cbSelectInputMethod;
        private System.Windows.Forms.Button saveFile;
        private System.Windows.Forms.Label lbSelectFileType;
        private System.Windows.Forms.Label lbSelectInputMethod;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.Label lbStringBytes;
        private System.Windows.Forms.Button btStop;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem decoderToolStripMenuItem;
        private System.Windows.Forms.PictureBox pbWaitReady;
        private System.Windows.Forms.Label lbSentCmd;
        private System.Windows.Forms.Label lbAlert;

        //static public EventTimerRaiser eventTimerRaiser;
    }
}