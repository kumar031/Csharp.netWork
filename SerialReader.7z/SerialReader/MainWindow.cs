﻿using System;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;
using System.Collections.Generic;

namespace SerialReader
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            GetAvailableSerialPorts();
            Control.CheckForIllegalCrossThreadCalls = false;
            connectedPortList = new List<ConnForm>();
        }

        private void GetAvailableSerialPorts()
        {
            String[] portNames = SerialPort.GetPortNames();
            cbPort.Items.AddRange(portNames);
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbPort.Text == "" || cbBaudRate.Text == "")
                {
                    lbConnectStatusMsg.Text = "Error: Please set both of the port and baud rate first!";
                    lbConnectStatusMsg.ForeColor = Color.Red;
                    lbConnectStatusMsg.Visible = true;
                }
                else
                {
                    connectedPortList.Add(new ConnForm(cbPort.Text, Convert.ToInt32(cbBaudRate.Text)));
                    connectedPortList[connectedPortList.Count - 1].Show();
                    lbConnectStatusMsg.Text = string.Empty;
                    lbConnectStatusMsg.Visible = false;

                }
            }
            catch (UnauthorizedAccessException e1)
            {
                lbConnectStatusMsg.Text = e1.Message; //   "Error: Unauthorized Access!!";
                lbConnectStatusMsg.ForeColor = Color.Red;
                lbConnectStatusMsg.Visible = true;
                return;
            }
            catch(ObjectDisposedException e1)
            {
                lbConnectStatusMsg.Text = e1.Message; //   "Error: Unauthorized Access!!";
                lbConnectStatusMsg.ForeColor = Color.Red;
                lbConnectStatusMsg.Visible = true;
                return;
            }
        }

        private void btnRefPort_Click(object sender, EventArgs e)
        {
            String[] portNames = SerialPort.GetPortNames();
            cbPort.Items.Clear();
            cbPort.Items.AddRange(portNames);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private DecodeForm maindecoderForm;

        private void decoderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            maindecoderForm = new DecodeForm();
            maindecoderForm.Show();
        }

        private void serialReaderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (maindecoderForm != null)
            {
                maindecoderForm.Close();
                maindecoderForm = null;
            }
        }
    }
}
