﻿using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace SerialReader
{
    public partial class DecodeForm : Form
    {
        public DecodeForm()
        {
            InitializeComponent();
        }

        //private TextBox textBox1;
        private RichTextBox txEncodedString;
        private RichTextBox txHexString;
        private RichTextBox txDecodedString;
        private Label lbEncodedStr;
        private Label lbDecodedStr;
        private Label lbHexStr;
        private Button btDecode;
        private Button btDecodeSave;
        private Button btClearTxt;
        private Button btFileSelect;
        private Button btSaveDecoded;
        private Button btClose;
        OpenFileDialog openUploadFile = new OpenFileDialog();

        //--------------------------------------------------------------------------------------
        private void InitializeComponent()
        {
            this.txEncodedString = new System.Windows.Forms.RichTextBox();
            this.txHexString = new System.Windows.Forms.RichTextBox();
            this.txDecodedString = new System.Windows.Forms.RichTextBox();
            this.lbEncodedStr = new System.Windows.Forms.Label();
            this.lbDecodedStr = new System.Windows.Forms.Label();
            this.lbHexStr = new System.Windows.Forms.Label();
            this.btDecode = new System.Windows.Forms.Button();
            this.btDecodeSave = new System.Windows.Forms.Button();
            this.btClearTxt = new System.Windows.Forms.Button();
            this.btFileSelect = new System.Windows.Forms.Button();
            this.btSaveDecoded = new System.Windows.Forms.Button();
            this.btClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txEncodedString
            // 
            this.txEncodedString.Location = new System.Drawing.Point(34, 37);
            this.txEncodedString.Name = "txEncodedString";
            this.txEncodedString.Size = new System.Drawing.Size(347, 290);
            this.txEncodedString.TabIndex = 0;
            this.txEncodedString.Text = "";
            this.txEncodedString.TextChanged += new System.EventHandler(this.txEncodedString_TextChanged);
            // 
            // txHexString
            // 
            this.txHexString.Location = new System.Drawing.Point(34, 360);
            this.txHexString.Name = "txHexString";
            this.txHexString.Size = new System.Drawing.Size(347, 272);
            this.txHexString.TabIndex = 1;
            this.txHexString.Text = "";
            this.txHexString.TextChanged += new System.EventHandler(this.txHexString_TextChanged);
            // 
            // txDecodedString
            // 
            this.txDecodedString.BackColor = System.Drawing.Color.FloralWhite;
            this.txDecodedString.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txDecodedString.Location = new System.Drawing.Point(513, 28);
            this.txDecodedString.Name = "txDecodedString";
            this.txDecodedString.Size = new System.Drawing.Size(907, 652);
            this.txDecodedString.TabIndex = 15;
            this.txDecodedString.Text = "";
            // 
            // lbEncodedStr
            // 
            this.lbEncodedStr.AutoSize = true;
            this.lbEncodedStr.Location = new System.Drawing.Point(31, 18);
            this.lbEncodedStr.Name = "lbEncodedStr";
            this.lbEncodedStr.Size = new System.Drawing.Size(97, 16);
            this.lbEncodedStr.TabIndex = 3;
            this.lbEncodedStr.Text = "Encoded string";
            // 
            // lbDecodedStr
            // 
            this.lbDecodedStr.AutoSize = true;
            this.lbDecodedStr.Location = new System.Drawing.Point(512, 12);
            this.lbDecodedStr.Name = "lbDecodedStr";
            this.lbDecodedStr.Size = new System.Drawing.Size(99, 16);
            this.lbDecodedStr.TabIndex = 4;
            this.lbDecodedStr.Text = "Decoded string";
            // 
            // lbHexStr
            // 
            this.lbHexStr.AutoSize = true;
            this.lbHexStr.Location = new System.Drawing.Point(31, 341);
            this.lbHexStr.Name = "lbHexStr";
            this.lbHexStr.Size = new System.Drawing.Size(66, 16);
            this.lbHexStr.TabIndex = 5;
            this.lbHexStr.Text = "Hex string";
            // 
            // btDecode
            // 
            this.btDecode.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btDecode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btDecode.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btDecode.Location = new System.Drawing.Point(34, 647);
            this.btDecode.Name = "btDecode";
            this.btDecode.Size = new System.Drawing.Size(90, 38);
            this.btDecode.TabIndex = 6;
            this.btDecode.Text = "Decode text";
            this.btDecode.UseVisualStyleBackColor = false;
            this.btDecode.Click += new System.EventHandler(this.btDecode_Click);
            // 
            // btDecodeSave
            // 
            this.btDecodeSave.BackColor = System.Drawing.Color.Chocolate;
            this.btDecodeSave.ForeColor = System.Drawing.Color.White;
            this.btDecodeSave.Location = new System.Drawing.Point(34, 647);
            this.btDecodeSave.Name = "btDecodeSave";
            this.btDecodeSave.Size = new System.Drawing.Size(90, 38);
            this.btDecodeSave.TabIndex = 7;
            this.btDecodeSave.Text = "Decode File";
            this.btDecodeSave.UseVisualStyleBackColor = false;
            this.btDecodeSave.Click += new System.EventHandler(this.btDecodeSave_Click_1);
            // 
            // btClearTxt
            // 
            this.btClearTxt.BackColor = System.Drawing.Color.FloralWhite;
            this.btClearTxt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btClearTxt.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btClearTxt.Location = new System.Drawing.Point(34, 691);
            this.btClearTxt.Name = "btClearTxt";
            this.btClearTxt.Size = new System.Drawing.Size(90, 30);
            this.btClearTxt.TabIndex = 8;
            this.btClearTxt.Text = "clear";
            this.btClearTxt.UseVisualStyleBackColor = false;
            this.btClearTxt.Click += new System.EventHandler(this.btClearTxt_Click);
            // 
            // btFileSelect
            // 
            this.btFileSelect.BackColor = System.Drawing.Color.FloralWhite;
            this.btFileSelect.Location = new System.Drawing.Point(291, 647);
            this.btFileSelect.Name = "btFileSelect";
            this.btFileSelect.Size = new System.Drawing.Size(90, 31);
            this.btFileSelect.TabIndex = 9;
            this.btFileSelect.Text = "Select file";
            this.btFileSelect.UseVisualStyleBackColor = false;
            this.btFileSelect.Click += new System.EventHandler(this.btFileSelect_Click);
            // 
            // btSaveDecoded
            // 
            this.btSaveDecoded.BackColor = System.Drawing.Color.Chocolate;
            this.btSaveDecoded.ForeColor = System.Drawing.Color.White;
            this.btSaveDecoded.Location = new System.Drawing.Point(513, 683);
            this.btSaveDecoded.Name = "btSaveDecoded";
            this.btSaveDecoded.Size = new System.Drawing.Size(90, 34);
            this.btSaveDecoded.TabIndex = 16;
            this.btSaveDecoded.Text = "Export";
            this.btSaveDecoded.UseVisualStyleBackColor = false;
            this.btSaveDecoded.Click += new System.EventHandler(this.btSaveDecoded_Click);
            // 
            // btClose
            // 
            this.btClose.BackColor = System.Drawing.Color.Red;
            this.btClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClose.Location = new System.Drawing.Point(1450, 28);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(85, 56);
            this.btClose.TabIndex = 17;
            this.btClose.Text = "CLOSE";
            this.btClose.UseVisualStyleBackColor = false;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // DecodeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1578, 770);
            this.Controls.Add(this.btClose);
            this.Controls.Add(this.btSaveDecoded);
            this.Controls.Add(this.btFileSelect);
            this.Controls.Add(this.btClearTxt);
            this.Controls.Add(this.btDecode);
            this.Controls.Add(this.lbHexStr);
            this.Controls.Add(this.lbDecodedStr);
            this.Controls.Add(this.lbEncodedStr);
            this.Controls.Add(this.txDecodedString);
            this.Controls.Add(this.txHexString);
            this.Controls.Add(this.txEncodedString);
            this.Controls.Add(this.btDecodeSave);
            this.Name = "DecodeForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void btDecode_Click(object sender, EventArgs e)
        {
            string decodedTextToHex = "";
            if ((txEncodedString.Text).Length >= 128)
            {
                string encoded64bitText = txEncodedString.Text;
                byte[] binaryData = null;
                int rectifyCount = 1;
                while (rectifyCount <= 5)
                {
                    try
                    {
                        binaryData = Convert.FromBase64String(encoded64bitText);
                        break;
                    }
                    catch (FormatException fe)
                    {
                        // Add a padding character to the end of the string and try again
                        //encoded64bitText += "=";
                        if (rectifyCount == 5)
                        {
                            MessageBox.Show(fe.ToString());
                            return;
                        }
                        encoded64bitText = string.Concat(encoded64bitText, "=");
                        txEncodedString.Text = encoded64bitText;
                    }
                    rectifyCount++;
                }

                try
                {
                    decodedTextToHex = BitConverter.ToString(binaryData).Replace("-", "");
                    decodeDataInChunks(decodedTextToHex, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                txHexString.Text = decodedTextToHex;
                txHexString.ReadOnly = true;
            }

            else if ((txHexString.Text).Length >= 128)
            {
                decodedTextToHex = string.Empty;
                decodedTextToHex = txHexString.Text;
                txEncodedString.ReadOnly = true;
                decodeDataInChunks(decodedTextToHex, null);
            }
        }

        private void btDecodeSave_Click_1(object sender, EventArgs e)
        {
            string base64TxtData = File.ReadAllText(openUploadFile.FileName);
            byte[] binaryData = null;
            string decodedTextToHex = "";
            int rectifyCount = 1;
            while (rectifyCount <= 5)
            {
                try
                {
                    binaryData = Convert.FromBase64String(base64TxtData);
                    break;
                }
                catch (FormatException fe)
                {
                    // Add a padding character to the end of the string and try again
                    //encoded64bitText += "=";
                    if (rectifyCount == 5)
                    {
                        MessageBox.Show(fe.ToString());
                        return;
                    }
                    base64TxtData = string.Concat(base64TxtData, "=");
                    txEncodedString.Text = base64TxtData;
                }
                rectifyCount++;
            }

            try
            {
                decodedTextToHex = BitConverter.ToString(binaryData).Replace("-", "");

                txHexString.Text = decodedTextToHex;
                decodeDataInChunks(decodedTextToHex, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btClearTxt_Click(object sender, EventArgs e)
        {
            txHexString.Text = txEncodedString.Text = string.Empty;
            txEncodedString.ReadOnly = false;
            txHexString.ReadOnly = false;
            btDecode.Visible = true;
            btDecodeSave.Visible = false;
            txDecodedString.Text = string.Empty;
        }

        private void btFileSelect_Click(object sender, EventArgs e)
        {
            if (System.Windows.Forms.DialogResult.OK == openUploadFile.ShowDialog())
            {
                // Get the file info for the selected file
                FileInfo fileInfo = new FileInfo(openUploadFile.FileName);

                // Get the file size in bytes
                long fileSizeInBytes = fileInfo.Length;

                string base64Data = File.ReadAllText(openUploadFile.FileName);
                txEncodedString.Text = base64Data;

                btDecode.Visible = false;
                btDecodeSave.Visible = true;

            }
        }

        private void btSaveDecoded_Click(object sender, EventArgs e)
        {
            string saveFilePath = "";
            //OpenFileDialog saveFile = new OpenFileDialog();
            SaveFileDialog saveFile = new SaveFileDialog();
            // Set the default file name and extension
            saveFile.FileName = "MyDecodedFile.txt";
            saveFile.DefaultExt = "txt";

            // Display the dialog box and get the result
            DialogResult result = saveFile.ShowDialog();

            if (result == DialogResult.OK)
            {
                saveFilePath = saveFile.FileName;
            }
            else
            {
                MessageBox.Show("give valid path to save file");
                return;
            }
            File.AppendAllText(saveFilePath, txDecodedString.Text);
        }

        private void ApplyHtmlFormatting(string htmlText)
        {
            //this.txDecodedString.Text = "";
            //this.txDecodedString.Text = ;
            int i_color = 0;

            // Define regular expressions for matching HTML-like tags
            var tagRegex = new Regex("<(.*?)>");
            var endTagRegex = new Regex("</(.*?)>");

            // Split the HTML text into individual tags and text segments
            var tagsAndText = tagRegex.Split(htmlText);
            int tagsAndTextLength = tagsAndText.Length;
            int totalStringLen = 0;
            char[] charArray = null;

            for (int i = 0; i < tagsAndTextLength; i++)
            //foreach (var item in tagsAndText)
            {
                var tagString = tagsAndText[i];
                if (tagsAndText[i].StartsWith("/"))
                {
                    // Handle closing tags
                    var endTagName = endTagRegex.Match(tagsAndText[i]).Groups[1].Value.ToLower();

                    //if (endTagName == "b") { };
                    //this.txDecodedString.SelectionFont = new Font(this.txDecodedString.Font, this.txDecodedString.Font.Style & ~FontStyle.Bold);
                    //else if (endTagName == "i") { };
                    //this.txDecodedString.SelectionFont = new Font(this.txDecodedString.Font, this.txDecodedString.Font.Style & ~FontStyle.Italic);
                    //else if (endTagName == "u") { };
                    //this.txDecodedString.SelectionFont = new Font(this.txDecodedString.Font, this.txDecodedString.Font.Style & ~FontStyle.Underline);
                }
                else if (!string.IsNullOrWhiteSpace(tagsAndText[i]))
                {
                    // Handle text segments and opening tags
                    var openTagName = tagsAndText[i].ToLower();

                    if (openTagName.StartsWith("color="))
                    {
                        var colorValue = openTagName.Substring(6); // Extract the color value from the tag

                        Color color;
                        if (Color.FromName(colorValue) != Color.Empty)
                        {
                            color = Color.FromName(colorValue); // Use named color
                            i = i + 1;
                            this.txDecodedString.AppendText(tagsAndText[i]);
                            tagString = tagsAndText[i];
                            charArray = txDecodedString.Text.ToCharArray();
                            int startIndex = totalStringLen; // Starting index of the text to format
                            int length = (tagsAndText[i].Length) - 1; // Length of the text to format
                            txDecodedString.SelectionStart = startIndex;
                            txDecodedString.SelectionLength = length;
                            //txDecodedString.SelectionFont = new Font(txDecodedString.Font, FontStyle.Bold);
                            txDecodedString.SelectionColor = Color.OrangeRed;
                        }
                        else if (colorValue.StartsWith("#") && colorValue.Length == 7)
                            color = ColorTranslator.FromHtml(colorValue); // Use hexadecimal color
                        else
                            color = Color.Black; // Use default color if invalid value

                        this.txDecodedString.SelectionColor = color;
                    }
                    else if (openTagName == "b")
                    {
                        i = i + 1;
                        this.txDecodedString.AppendText(tagsAndText[i]);
                        tagString = tagsAndText[i];
                        charArray = txDecodedString.Text.ToCharArray();
                        int startIndex = totalStringLen; // Starting index of the text to format
                        int length = (tagsAndText[i].Length) - 1; // Length of the text to format
                        txDecodedString.SelectionStart = startIndex;
                        txDecodedString.SelectionLength = length;

                        txDecodedString.SelectionFont = new Font(txDecodedString.Font, FontStyle.Bold);
                        if (i_color == 0)
                        {
                            txDecodedString.SelectionColor = Color.OrangeRed;
                        }
                        else
                        {
                            txDecodedString.SelectionColor = Color.DarkOrchid;
                        }
                        //BoldText(tagsAndText[i]);
                    }
                    //this.txDecodedString.SelectionFont = new Font(this.txDecodedString.Font, this.txDecodedString.Font.Style | FontStyle.Bold);
                    else if (openTagName == "i")
                        this.txDecodedString.SelectionFont = new Font(this.txDecodedString.Font, this.txDecodedString.Font.Style | FontStyle.Italic);
                    else if (openTagName == "u")
                        this.txDecodedString.SelectionFont = new Font(this.txDecodedString.Font, this.txDecodedString.Font.Style | FontStyle.Underline);
                    else
                    {
                        if (tagsAndText[i].Contains("OK"))
                        {
                            string output = tagsAndText[i].Replace("\r\n\r\nOK\r\n^^^^", "");
                            this.txDecodedString.AppendText(output);
                            charArray = txDecodedString.Text.ToCharArray();

                        }
                        else
                        {
                            /*  string pattern = @"(\d+)\r\n";
                            Match match = Regex.Match(tagsAndText[i], pattern);
                            if (match.Success)
                            {
                                string numberString = match.Groups[1].Value;
                                this.txDecodedString.AppendText(numberString+" \r\n ");
                            }*/
                            this.txDecodedString.AppendText(tagsAndText[i]);
                            charArray = txDecodedString.Text.ToCharArray();
                        }

                        if (tagsAndText[i].Contains("_____________"))
                        {
                            /*if (i_color==0)
                            {
                                i_color = i_color ^ 1;
                            }
                            else
                            {
                                i_color = i_color ^ 0;
                            }*/
                            i_color = i_color ^ 1;
                        }
                    }
                }
                else
                {
                    this.txDecodedString.AppendText(tagsAndText[i]);
                }
                totalStringLen = txDecodedString.Text.Length;
            }
        }

        private void BoldText(string text)
        {
            // Save the current selection
            int selectionStart = txDecodedString.SelectionStart;
            int selectionLength = txDecodedString.SelectionLength;

            // Find the text in the RichTextBox
            int startIndex = txDecodedString.Text.IndexOf(text);
            if (startIndex != -1)
            {
                // Select the desired text
                txDecodedString.Select(startIndex, text.Length);

                // Set the font to bold
                txDecodedString.SelectionFont = new Font(txDecodedString.Font, FontStyle.Bold);
            }

            // Restore the original selection
            txDecodedString.Select(selectionStart, selectionLength);
        }

        void decodeDataInChunks(string hexTextData, string saveFilePath)
        {
            int chunkSize = 342;
            int Offset = 82;

            //offsetting the decodedHexText with 89 character, as 1st 89 character is json header, not data
            // decodedHexText = decodedHexText.Substring(82);

            //StringBuilder resultTxt = new StringBuilder(decodedText.Length / 2);
            string decodedOutput = "";
            string offsetChunk = "";
            //txEncodedString.Text = base64Data;
            int count = 1;
            for (int i = 0; i < hexTextData.Length; i += chunkSize)
            {
                string saperatorLine = $"\n__________________________________________{count}_______________________________________________\n\n";
                int remainingLength = hexTextData.Length - i;
                int chunkLength = remainingLength > chunkSize ? chunkSize : remainingLength;
                string chunk = hexTextData.Substring(i, chunkLength);
                if (remainingLength >= Offset)
                {
                    offsetChunk = chunk.Substring(Offset);
                }
                else if (offsetChunk.Length < 256)
                {
                    MessageBox.Show("data < 128 bytes, not enough to decode ");
                    return;
                }
                string decodedChunk = decodeHex(offsetChunk);
                //resultTxt.Append(decodedChunk);
                decodedOutput += decodedChunk + Environment.NewLine + saperatorLine + Environment.NewLine;
                //txHexString.Text = chunk;
                //txOutputBox.Text = resultTxt.ToString();
                //txOutputBox.Text = decodedOutput;
                if (saveFilePath != null)
                {
                    File.AppendAllText(saveFilePath, $"{count}------------------------------------------------------------" + Environment.NewLine);
                    File.AppendAllText(saveFilePath, decodedChunk + Environment.NewLine);
                    File.AppendAllText(saveFilePath, "____________________________________________________________________" + Environment.NewLine);
                }
                count++;
            }
            ApplyHtmlFormatting(decodedOutput);
        }

        byte[] btDecodeHexToInt(string hexString)
        {
            byte[] bytes = new byte[hexString.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                bytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            }
            return bytes;
        }

        //-----------------------------------------------------------------------------------------
        string decodeHex(string decodedHexText)
        {
            txHexString.Text = string.Empty;
            txHexString.Text = decodedHexText;
            string newText = "";
            //string newHexText = "";
            try
            {

                string RecDate = decodedHexText.Substring(0, 6);
                string RecTime = decodedHexText.Substring(6, 6);

                string SysEvents = decodedHexText.Substring(12, 16);

                string GpsData = decodedHexText.Substring(28, 152);

                string CanData = decodedHexText.Substring(180, 16);
                string canOdoMeter = CanData.Substring(0, 12);
                string canSpeed = CanData.Substring(12, 4);

                string AccGyrData = decodedHexText.Substring(196, 48);
                string accXaxis = AccGyrData.Substring(0, 16);
                string accYaxis = AccGyrData.Substring(16, 16);
                string accZaxis = AccGyrData.Substring(32, 16);

                /*               
                                string RecDate = decodedHexText.Substring(0, 12);
                                string RecTime = decodedHexText.Substring(12, 12);
                                string SysEvents = decodedHexText.Substring(24, 16);

                                string GpsData = decodedHexText.Substring(40, 152);
                                string CanData = decodedHexText.Substring(192, 16);
                                string AccGyrData = decodedHexText.Substring(208, 48);

                                string canOdoMeter = CanData.Substring(0, 12);
                                string canSpeed = CanData.Substring(12, 4);
                                string accXaxis = AccGyrData.Substring(0, 16);
                                string accYaxis = AccGyrData.Substring(16, 16);
                                string accZaxis = AccGyrData.Substring(32, 16);*/

                string separator = "2C";

                string[] gpsElementStr = GpsData.Split(new string[] { separator }, StringSplitOptions.None);

                if (gpsElementStr.Length < 11)
                {
                    Array.Resize(ref gpsElementStr, 11);
                }
                for (int i = 0; i < gpsElementStr.Length; i++)
                {
                    if (gpsElementStr[i] == null)
                    {
                        gpsElementStr[i] = "4e554c4c";
                    }
                }

                //=============================================================
                byte[] replacement = { 94 };

                //byte[] RecDateBytes = (btDecodeHexToInt(RecDate)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                //byte[] RecTimeBytes = (btDecodeHexToInt(RecTime)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                int RecDateInt32 = Convert.ToInt32(RecDate, 16);
                int RecTimeInt32 = Convert.ToInt32(RecTime, 16);

                byte[] SysEventsBytes = (btDecodeHexToInt(SysEvents));//.Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] SysEventsBytesWithReplacement = (btDecodeHexToInt(SysEvents)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();

                byte[] GPSbytes = (btDecodeHexToInt(GpsData)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();

                byte[] gpsUTCBytes = (btDecodeHexToInt(gpsElementStr[0])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpslatitudeBytes = (btDecodeHexToInt(gpsElementStr[1])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpslongitudeBytes = (btDecodeHexToInt(gpsElementStr[2])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsHDOPBytes = (btDecodeHexToInt(gpsElementStr[3])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsAltitudeBytes = (btDecodeHexToInt(gpsElementStr[4])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsFixBytes = (btDecodeHexToInt(gpsElementStr[5])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsCogBytes = (btDecodeHexToInt(gpsElementStr[6])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsSpkmBytes = (btDecodeHexToInt(gpsElementStr[7])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsSpknBytes = (btDecodeHexToInt(gpsElementStr[8])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsDateBytes = (btDecodeHexToInt(gpsElementStr[9])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] gpsNsatBytes = (btDecodeHexToInt(gpsElementStr[10])).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();

                byte[] CANbytesBytes = (btDecodeHexToInt(CanData)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] odoMeterBytes = (btDecodeHexToInt(canOdoMeter)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] speedBytes = (btDecodeHexToInt(canSpeed)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();

                byte[] accGyrBytes = (btDecodeHexToInt(AccGyrData)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] xAxisBytes = (btDecodeHexToInt(accXaxis)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] yAxisBytes = (btDecodeHexToInt(accYaxis)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                byte[] zAxisBytes = (btDecodeHexToInt(accZaxis)).Select(b => b == 0 ? replacement : new byte[] { b }).SelectMany(b => b).ToArray();
                //===============================================================

                //string strRecDate = Encoding.ASCII.GetString(RecDateBytes);
                //string strRecTime = Encoding.ASCII.GetString(RecTimeBytes);

                int RecDateDay  = (RecDateInt32 & 0xFF0000) >> 16;
                int RecDateMon  = (RecDateInt32 & 0x00FF00) >> 8;
                int RecDateYr   = (RecDateInt32 & 0x0000FF);
                string strRecDate = RecDateDay.ToString() +"/"+ RecDateMon.ToString() + "/" + RecDateYr.ToString();

                int RecTimeHr  = (RecTimeInt32 & 0xFF0000) >> 16;
                int RecTimeMin = (RecTimeInt32 & 0x00FF00) >> 8;
                int RecTimeSec = (RecTimeInt32 & 0x0000FF);
                string strRecTime = RecTimeHr.ToString() +":"+ RecTimeMin.ToString() + ":" + RecTimeSec.ToString();

                string strSysEvents = Encoding.ASCII.GetString(SysEventsBytesWithReplacement);


                //string[] SysEventsBinaryStr = Array.btDecodeAll(SysEventsBytes, b => Convert.ToString(b, 2).PadLeft(8, '0'));

                string[] SysEventsBinaryStr = Array.ConvertAll(SysEventsBytes, b => Convert.ToString(b, 2).PadLeft(8, '0'));

                int[] SysEventsBinaryStrByte0 = SysEventsBinaryStr[0].Select(b => (int)Char.GetNumericValue(b)).ToArray();
                int[] SysEventsBinaryStrByte1 = SysEventsBinaryStr[1].Select(b => (int)Char.GetNumericValue(b)).ToArray();

                string strGPS = Encoding.ASCII.GetString(GPSbytes);
                string strUTC = (Encoding.ASCII.GetString(gpsUTCBytes));
                string strLatitude = Encoding.ASCII.GetString(gpslatitudeBytes);
                string strLongitude = Encoding.ASCII.GetString(gpslongitudeBytes);
                string strHDOP = Encoding.ASCII.GetString(gpsHDOPBytes);
                string strAltitude = Encoding.ASCII.GetString(gpsAltitudeBytes);
                string strFix = Encoding.ASCII.GetString(gpsFixBytes);
                string strCog = Encoding.ASCII.GetString(gpsCogBytes);
                string strSpkm = Encoding.ASCII.GetString(gpsSpkmBytes);
                string strSpkn = Encoding.ASCII.GetString(gpsSpknBytes);
                string strDate = Encoding.ASCII.GetString(gpsDateBytes);
                string strNsat = Encoding.ASCII.GetString(gpsNsatBytes);
                string strCan = Encoding.ASCII.GetString(CANbytesBytes);
                string strOdoMeter = Encoding.ASCII.GetString(odoMeterBytes);



                string strSpeed = Encoding.ASCII.GetString(speedBytes);
                string strAccGyr = Encoding.ASCII.GetString(accGyrBytes);
                string strXaxis = Encoding.ASCII.GetString(xAxisBytes);
                string strYaxis = Encoding.ASCII.GetString(yAxisBytes);
                string strZaxis = Encoding.ASCII.GetString(zAxisBytes);

                newText = String.Format("<b> Date:</b> {0} \r\n <b>Time:</b> {1} \r\n <b>Sys_events:</b> {2} " +
                    "\r\n {35}<b>SYS_EVENT_TAMPER:</b> {3} \r\n {35}<b>SYS_EVENT_RTC_SYNC_ERR:</b> {4} " +
                    "\r\n {35}<b>SYS_EVENT_BAT_ON:</b> {5} \r\n {35}<b>SYS_EVENT_BAT_CRIT:</b> {6} " +
                    "\r\n {35}<b>SYS_EVENT_TEMP_CRIT:</b> {7} \r\n {35}<b>SYS_EVENT_FOTA_REQ:</b> {8} " +
                    "\r\n {35}<b>SYS_EVENT_MODEM_ERR:</b> {9} \r\n {35}<b>SYS_EVENT_GPS_ERR:</b> {10} " +
                    "\r\n {35}<b>SYS_EVENT_MQTT_ERR:</b> {11} \r\n {35}<b>SYS_EVENT_SD_WR_ERR:</b> {12}" +
                    "\r\n {35}<b>SYS_EVENT_HARSH_ACC:</b> {13} \r\n {35}<b>SYS_EVENT_HARSH_BRAKE:</b> {14} " +
                    "\r\n {35}<b>SYS_EVENT_CAN_DATA_INVALID:</b> {15} \r\n <b>Gps:</b> {16} " +
                    "\r\n {35}<b>UTC:</b> {17} \r\n {35}<b>Latitude:</b> {18} " +
                    "\r\n {35}<b>Longitude:</b> {19} " +
                    "\r\n {35}<b>HDOP:</b> {20} \r\n {35}<b>Altitude:</b> {21} " +
                    "\r\n {35}<b>Fix:</b> {22} " +
                    "\r\n {35}<b>COG:</b> {23} \r\n {35}<b>Spkm:</b> {24} " +
                    "\r\n {35}<b>Spkn:</b> {25} " +
                    "\r\n {35}<b>Date:</b> {26} \r\n {35}<b>Nsat:</b> {27} \r\n <b>Can:</b> {28} " +
                    "\r\n {35}<b>Odometer:</b> {29} \r\n {35}<b>Speed:</b> {30} \r\n <b>Accelerometer:</b> {31} " +
                    "\r\n {35}<b>X:</b> {32} \r\n {35}<b>Y:</b> {33} \r\n {35}<b>Z:</b> {34}  ",
                    strRecDate, strRecTime, strSysEvents, Convert.ToString(SysEventsBinaryStrByte0[0], 2),
                    Convert.ToString(SysEventsBinaryStrByte0[1], 2), Convert.ToString(SysEventsBinaryStrByte0[2], 2),
                    Convert.ToString(SysEventsBinaryStrByte0[3], 2), Convert.ToString(SysEventsBinaryStrByte0[4], 2),
                    Convert.ToString(SysEventsBinaryStrByte0[5], 2), Convert.ToString(SysEventsBinaryStrByte0[6], 2),
                    Convert.ToString(SysEventsBinaryStrByte0[7], 2), Convert.ToString(SysEventsBinaryStrByte1[0], 2),
                    Convert.ToString(SysEventsBinaryStrByte1[1], 2), Convert.ToString(SysEventsBinaryStrByte1[2], 2),
                    Convert.ToString(SysEventsBinaryStrByte1[3], 2), Convert.ToString(SysEventsBinaryStrByte1[4], 2),
                    strGPS, strUTC, strLatitude, strLongitude, strHDOP, strAltitude, strFix, strCog, strSpkm, strSpkn,
                    strDate, strNsat, strCan, strOdoMeter, strSpeed, strAccGyr, strXaxis, strYaxis, strZaxis, "     ");


                   /*newHexText = String.Format(" date: {0} \r\n time: {1} \r\n sys_events: {2} \r\n gps: {3} \r\n {22}UTC: {4} " +
                    "\r\n {22}latitude: {5} \r\n {22}longitude: {6} \r\n {22}HDOP: {7} \r\n {22}altitude: {8} \r\n {22}fix: {9} " +
                    "\r\n {22}COG: {10} \r\n {22}spkm: {11} \r\n {22}spkn: {12} \r\n {22}date: {13} \r\n {22}nsat: {14} \r\n can: {15} \r\n {22}odometer: {16}" +
                    "\r\n {22}speed: {17} \r\n accelerometer: {18} \r\n {22}X: {19} \r\n {22}Y: {20} \r\n {22}Z: {21}  ",
                    RecDate, RecTime, SysEvents, GpsData, gpsElementStr[0], gpsElementStr[1], gpsElementStr[2], gpsElementStr[3],
                    gpsElementStr[4], gpsElementStr[5], gpsElementStr[6], gpsElementStr[7], gpsElementStr[8], gpsElementStr[9], gpsElementStr[10],
                    CanData, canOdoMeter, canSpeed, AccGyrData, accXaxis, accYaxis, accZaxis, "     ");*/

                //hexDecode.Text = newHexText;

            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
            return newText;
        }

        private void txEncodedString_TextChanged(object sender, EventArgs e)
        {
            txEncodedString.ReadOnly = false;
            txHexString.ReadOnly = true;
        }

        private void txHexString_TextChanged(object sender, EventArgs e)
        {
            txEncodedString.ReadOnly = true;
            txHexString.ReadOnly = false;
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}